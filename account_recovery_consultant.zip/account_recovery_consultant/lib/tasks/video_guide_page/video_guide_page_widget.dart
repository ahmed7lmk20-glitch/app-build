import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_ad_banner.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'video_guide_page_model.dart';
export 'video_guide_page_model.dart';

class VideoGuidePageWidget extends StatefulWidget {
  const VideoGuidePageWidget({super.key});

  static String routeName = 'video_guide_page';
  static String routePath = '/videoGuidePage';

  @override
  State<VideoGuidePageWidget> createState() => _VideoGuidePageWidgetState();
}

class _VideoGuidePageWidgetState extends State<VideoGuidePageWidget> {
  late VideoGuidePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VideoGuidePageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
          FocusManager.instance.primaryFocus?.unfocus();
        },
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: Color(0xFFF1F4F8),
          body: SafeArea(
            top: true,
            child: Container(
              width: MediaQuery.sizeOf(context).width * 1.0,
              height: MediaQuery.sizeOf(context).height * 1.0,
              child: Stack(
                children: [
                  Align(
                    alignment: AlignmentDirectional(0.0, 0.0),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.asset(
                        'assets/images/_2.jpg',
                        width: MediaQuery.sizeOf(context).width * 1.0,
                        height: MediaQuery.sizeOf(context).height * 1.0,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      FlutterFlowAdBanner(
                        width: MediaQuery.sizeOf(context).width * 1.0,
                        height: 50.0,
                        showsTestAd: false,
                        androidAdUnitID:
                            'ca-app-pub-2079997928257932/1007847958',
                      ),
                      Container(
                        width: 100.0,
                        height: MediaQuery.sizeOf(context).height * 0.22,
                        decoration: BoxDecoration(),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                        child: StreamBuilder<List<AppConfigurationRecord>>(
                          stream: queryAppConfigurationRecord(
                            singleRecord: true,
                          ),
                          builder: (context, snapshot) {
                            // Customize what your widget looks like when it's loading.
                            if (!snapshot.hasData) {
                              return Center(
                                child: SizedBox(
                                  width: 50.0,
                                  height: 50.0,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      FlutterFlowTheme.of(context).primary,
                                    ),
                                  ),
                                ),
                              );
                            }
                            List<AppConfigurationRecord>
                                youtubePlayerAppConfigurationRecordList =
                                snapshot.data!;
                            // Return an empty Container when the item does not exist.
                            if (snapshot.data!.isEmpty) {
                              return Container();
                            }
                            final youtubePlayerAppConfigurationRecord =
                                youtubePlayerAppConfigurationRecordList
                                        .isNotEmpty
                                    ? youtubePlayerAppConfigurationRecordList
                                        .first
                                    : null;

                            return FlutterFlowYoutubePlayer(
                              url: valueOrDefault<String>(
                                '${youtubePlayerAppConfigurationRecord?.tutorialVideoUrl}',
                                'https://www.youtube.com/watch?v=pUb9EW770d0&cc_load_policy=1',
                              ),
                              width: MediaQuery.sizeOf(context).width * 0.83,
                              height: MediaQuery.sizeOf(context).height * 0.45,
                              autoPlay: false,
                              looping: true,
                              mute: false,
                              showControls: true,
                              showFullScreen: true,
                              strictRelatedVideos: true,
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(5.0),
                        child: FFButtonWidget(
                          onPressed: () async {
                            _model.isReady =
                                await actions.loadRewardedInterstitialAd(
                              context,
                            );
                            if (_model.isReady == true) {
                              _model.gotReward =
                                  await actions.showRewardedInterstitialAd(
                                context,
                              );
                              if (_model.gotReward!) {
                                _model.userOrderDoc =
                                    await queryOrdersRecordOnce(
                                  queryBuilder: (ordersRecord) =>
                                      ordersRecord.where(
                                    'user_id',
                                    isEqualTo: currentUserUid,
                                  ),
                                  singleRecord: true,
                                ).then((s) => s.firstOrNull);
                                if (_model.userOrderDoc != null) {
                                  await _model.userOrderDoc!.reference.update({
                                    ...mapToFirestore(
                                      {
                                        'queue_number':
                                            FieldValue.increment(-(1)),
                                      },
                                    ),
                                  });
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        FFLocalizations.of(context)
                                            .getVariableText(
                                          arText:
                                              'تم خصم 1 دور من ترتيبك بنجاح 🎁',
                                          enText:
                                              '1 turn successfully deducted from your queue! 🎁',
                                        ),
                                        style: TextStyle(
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                      duration: Duration(milliseconds: 3000),
                                      backgroundColor:
                                          FlutterFlowTheme.of(context)
                                              .secondary,
                                    ),
                                  );

                                  context.pushNamed(
                                      CreateOrderPageWidget.routeName);
                                } else {
                                  context.pushNamed(
                                      CreateOrderPageWidget.routeName);
                                }
                              } else {
                                context
                                    .pushNamed(CreateOrderPageWidget.routeName);
                              }
                            } else {
                              context
                                  .pushNamed(CreateOrderPageWidget.routeName);
                            }

                            safeSetState(() {});
                          },
                          text: FFLocalizations.of(context).getText(
                            'bzhl7j3z' /* قدم طلب الان */,
                          ),
                          options: FFButtonOptions(
                            height: 50.0,
                            padding: EdgeInsetsDirectional.fromSTEB(
                                16.0, 0.0, 16.0, 0.0),
                            iconPadding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            color: FlutterFlowTheme.of(context).secondary,
                            textStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  font: GoogleFonts.interTight(
                                    fontWeight: FontWeight.bold,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  fontSize: 18.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .fontStyle,
                                ),
                            elevation: 0.0,
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                      ),
                      Spacer(),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
