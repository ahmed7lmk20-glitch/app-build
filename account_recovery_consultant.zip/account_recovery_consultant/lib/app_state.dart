import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:csv/csv.dart';
import 'package:synchronized/synchronized.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'dart:convert';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    secureStorage = FlutterSecureStorage();
    await _safeInitAsync(() async {
      _adCount = await secureStorage.getInt('ff_adCount') ?? _adCount;
    });
    await _safeInitAsync(() async {
      _adResetTime = await secureStorage.read(key: 'ff_adResetTime') != null
          ? DateTime.fromMillisecondsSinceEpoch(
              (await secureStorage.getInt('ff_adResetTime'))!)
          : _adResetTime;
    });
    await _safeInitAsync(() async {
      _adIndex = await secureStorage.getInt('ff_adIndex') ?? _adIndex;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late FlutterSecureStorage secureStorage;

  int _adCount = 0;
  int get adCount => _adCount;
  set adCount(int value) {
    _adCount = value;
    secureStorage.setInt('ff_adCount', value);
  }

  void deleteAdCount() {
    secureStorage.delete(key: 'ff_adCount');
  }

  DateTime? _adResetTime = DateTime.fromMillisecondsSinceEpoch(1783629360000);
  DateTime? get adResetTime => _adResetTime;
  set adResetTime(DateTime? value) {
    _adResetTime = value;
    value != null
        ? secureStorage.setInt('ff_adResetTime', value.millisecondsSinceEpoch)
        : secureStorage.remove('ff_adResetTime');
  }

  void deleteAdResetTime() {
    secureStorage.delete(key: 'ff_adResetTime');
  }

  dynamic _myRewardedAd;
  dynamic get myRewardedAd => _myRewardedAd;
  set myRewardedAd(dynamic value) {
    _myRewardedAd = value;
  }

  DateTime? _tenDaysAgo;
  DateTime? get tenDaysAgo => _tenDaysAgo;
  set tenDaysAgo(DateTime? value) {
    _tenDaysAgo = value;
  }

  int _userOrderNumber = 0;
  int get userOrderNumber => _userOrderNumber;
  set userOrderNumber(int value) {
    _userOrderNumber = value;
  }

  int _adIndex = 0;
  int get adIndex => _adIndex;
  set adIndex(int value) {
    _adIndex = value;
    secureStorage.setInt('ff_adIndex', value);
  }

  void deleteAdIndex() {
    secureStorage.delete(key: 'ff_adIndex');
  }

  bool _pendingratingshow = false;
  bool get pendingratingshow => _pendingratingshow;
  set pendingratingshow(bool value) {
    _pendingratingshow = value;
  }

  bool _hasrated = false;
  bool get hasrated => _hasrated;
  set hasrated(bool value) {
    _hasrated = value;
  }

  dynamic _myRewardedInterstitialAd;
  dynamic get myRewardedInterstitialAd => _myRewardedInterstitialAd;
  set myRewardedInterstitialAd(dynamic value) {
    _myRewardedInterstitialAd = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}

extension FlutterSecureStorageExtensions on FlutterSecureStorage {
  static final _lock = Lock();

  Future<void> writeSync({required String key, String? value}) async =>
      await _lock.synchronized(() async {
        await write(key: key, value: value);
      });

  void remove(String key) => delete(key: key);

  Future<String?> getString(String key) async => await read(key: key);
  Future<void> setString(String key, String value) async =>
      await writeSync(key: key, value: value);

  Future<bool?> getBool(String key) async => (await read(key: key)) == 'true';
  Future<void> setBool(String key, bool value) async =>
      await writeSync(key: key, value: value.toString());

  Future<int?> getInt(String key) async =>
      int.tryParse(await read(key: key) ?? '');
  Future<void> setInt(String key, int value) async =>
      await writeSync(key: key, value: value.toString());

  Future<double?> getDouble(String key) async =>
      double.tryParse(await read(key: key) ?? '');
  Future<void> setDouble(String key, double value) async =>
      await writeSync(key: key, value: value.toString());

  Future<List<String>?> getStringList(String key) async =>
      await read(key: key).then((result) {
        if (result == null || result.isEmpty) {
          return null;
        }
        return CsvToListConverter()
            .convert(result)
            .first
            .map((e) => e.toString())
            .toList();
      });
  Future<void> setStringList(String key, List<String> value) async =>
      await writeSync(key: key, value: ListToCsvConverter().convert([value]));
}
