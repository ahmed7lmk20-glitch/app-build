import '/flutter_flow/flutter_flow_ad_banner.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'forgot_password_page_widget.dart' show ForgotPasswordPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ForgotPasswordPageModel
    extends FlutterFlowModel<ForgotPasswordPageWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for forgot_email_field widget.
  FocusNode? forgotEmailFieldFocusNode;
  TextEditingController? forgotEmailFieldTextController;
  String? Function(BuildContext, String?)?
      forgotEmailFieldTextControllerValidator;
  // Stores action output result for [Custom Action - customResetPassword] action in Button widget.
  bool? tota;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    forgotEmailFieldFocusNode?.dispose();
    forgotEmailFieldTextController?.dispose();
  }
}
