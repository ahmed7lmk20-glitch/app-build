// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages2/main_page/main_page_widget.dart' show MainPageWidget;
export '/pages/sign_up_page/sign_up_page_widget.dart' show SignUpPageWidget;
export '/pages/forgot_password_page/forgot_password_page_widget.dart'
    show ForgotPasswordPageWidget;
export '/pages2/create_order_page/create_order_page_widget.dart'
    show CreateOrderPageWidget;
export '/pages2/my_orders_page/my_orders_page_widget.dart'
    show MyOrdersPageWidget;
export '/pages2/policies_page/policies_page_widget.dart'
    show PoliciesPageWidget;
export '/tasks/explainer_page/explainer_page_widget.dart'
    show ExplainerPageWidget;
export '/tasks/publish_guide_page/publish_guide_page_widget.dart'
    show PublishGuidePageWidget;
export '/tasks/submit_task_page/submit_task_page_widget.dart'
    show SubmitTaskPageWidget;
export '/admin/admin_dashboard/admin_dashboard_widget.dart'
    show AdminDashboardWidget;
export '/admin/order_details/order_details_widget.dart' show OrderDetailsWidget;
export '/admin/admin_panel/admin_panel_widget.dart' show AdminPanelWidget;
export '/tasks/video_guide_page/video_guide_page_widget.dart'
    show VideoGuidePageWidget;
export '/admin/inactive_orders_page/inactive_orders_page_widget.dart'
    show InactiveOrdersPageWidget;
export '/admin/admin_stats_page/admin_stats_page_widget.dart'
    show AdminStatsPageWidget;
