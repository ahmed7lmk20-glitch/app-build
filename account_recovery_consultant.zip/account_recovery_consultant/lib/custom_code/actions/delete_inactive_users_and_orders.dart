// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';

Future deleteInactiveUsersAndOrders(DateTime? tenDaysAgo) async {
  if (tenDaysAgo == null) return;

  try {
    // 1. جلب أقدم 20 مستخدم خامل
    final usersSnapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('last_login', isLessThan: tenDaysAgo)
        .limit(20) // حد أقصى 20 في الضغطة
        .get();

    if (usersSnapshot.docs.isEmpty) return;

    final batch = FirebaseFirestore.instance.batch();

    for (var doc in usersSnapshot.docs) {
      // 2. جلب وحذف طلبات هذا المستخدم
      final ordersSnapshot = await FirebaseFirestore.instance
          .collection('orders')
          .where('user_id', isEqualTo: doc.id)
          .get();

      for (var orderDoc in ordersSnapshot.docs) {
        batch.delete(orderDoc.reference);
      }

      // 3. حذف وثيقة المستخدم الخامل نفسها نهائياً من users
      batch.delete(doc.reference);
    }

    // تنفيذ الحذف دفعة واحدة
    await batch.commit();
  } catch (e) {
    print('Error in deleting inactive users and orders: $e');
  }
}
