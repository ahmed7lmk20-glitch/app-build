// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'dart:async';

Future<bool> showMyAd(BuildContext context) async {
  // بنقرأ الإعلان من الـ App State مباشرة
  final dynamic adObject = FFAppState().myRewardedAd;

  if (adObject == null || adObject is! RewardedAd) {
    return false; // لو مفيش إعلان حقيقي مشحون يرجع False
  }

  final RewardedAd adToShow = adObject;
  final completer = Completer<bool>();
  bool hasWatched = false;

  adToShow.fullScreenContentCallback = FullScreenContentCallback(
    onAdDismissedFullScreenContent: (Ad ad) {
      ad.dispose();
      FFAppState().myRewardedAd = null; // تنظيف الذاكرة بعد الإغلاق
      completer.complete(hasWatched);
    },
    onAdFailedToShowFullScreenContent: (Ad ad, AdError error) {
      ad.dispose();
      FFAppState().myRewardedAd = null;
      completer.complete(false);
    },
  );

  await adToShow.show(
    onUserEarnedReward: (AdWithoutView ad, RewardItem reward) {
      hasWatched = true;
    },
  );

  return completer.future;
}
