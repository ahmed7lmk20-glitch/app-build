// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:async';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '/custom_code/actions/load_rewarded_interstitial_ad.dart';

Future<bool> showRewardedInterstitialAd(BuildContext context) async {
  if (globalRewardedInterstitialAd == null) {
    return false; // لا يوجد إعلان جاهز في الذاكرة
  }

  Completer<bool> completer = Completer<bool>();
  bool userEarnedReward = false;

  // إعداد الأحداث فور إغلاق أو فتح الإعلان
  globalRewardedInterstitialAd!.fullScreenContentCallback =
      FullScreenContentCallback(
    onAdDismissedFullScreenContent: (RewardedInterstitialAd ad) {
      ad.dispose();
      globalRewardedInterstitialAd = null;
      if (!completer.isCompleted) {
        completer.complete(userEarnedReward);
      }
    },
    onAdFailedToShowFullScreenContent:
        (RewardedInterstitialAd ad, AdError error) {
      ad.dispose();
      globalRewardedInterstitialAd = null;
      if (!completer.isCompleted) {
        completer.complete(false);
      }
    },
  );

  // عرض الإعلان واستقبال حدث استحقاق المكافأة من AdMob
  globalRewardedInterstitialAd!.show(
    onUserEarnedReward: (AdWithoutView ad, RewardItem reward) {
      userEarnedReward = true;
    },
  );

  return await completer.future;
}
