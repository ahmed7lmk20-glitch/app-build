// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:firebase_auth/firebase_auth.dart';

Future<bool> customLogin(
  BuildContext context,
  String email,
  String password,
) async {
  // 1. معرفة لغة التطبيق الحالية (ar أو en)
  String currentLanguage = FFLocalizations.of(context).languageCode;
  bool isArabic = currentLanguage == 'ar';

  try {
    // 2. محاولة تسجيل الدخول عبر Firebase Auth
    await FirebaseAuth.instance.signInWithEmailAndPassword(
      email: email.trim(),
      password: password.trim(),
    );

    // نجح تسجيل الدخول
    return true;
  } on FirebaseAuthException catch (e) {
    // 3. التقاط كود الخطأ وتحديد الرسالة المترجمة
    String message = '';

    switch (e.code) {
      case 'user-not-found':
      case 'invalid-credential':
      case 'wrong-password':
        message = isArabic
            ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.'
            : 'Invalid email or password.';
        break;

      case 'invalid-email':
        message = isArabic
            ? 'صيغة البريد الإلكتروني غير صحيحة.'
            : 'The email address is badly formatted.';
        break;

      case 'user-disabled':
        message = isArabic
            ? 'تم إيقاف هذا الحساب، يرجى التواصل مع الدعم.'
            : 'This user account has been disabled.';
        break;

      case 'too-many-requests':
        message = isArabic
            ? 'تم تقديم محاولات كثيرة خاطئة، يرجى الانتظار قليلاً.'
            : 'Too many unsuccessful attempts. Please try again later.';
        break;

      case 'network-request-failed':
        message = isArabic
            ? 'يرجى التأكد من اتصالك بالإنترنت.'
            : 'Please check your internet connection.';
        break;

      default:
        message = isArabic
            ? 'حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.'
            : 'An unexpected error occurred. Please try again.';
        break;
    }

    // 4. إظهار SnackBar أنيق بالرسالة المترجمة
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(color: Colors.white, fontFamily: 'Readex Pro'),
        ),
        backgroundColor: Color(0xFFDC2626), // أحمر نيون أنيق للخطأ
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
    );

    return false;
  } catch (e) {
    return false;
  }
}
