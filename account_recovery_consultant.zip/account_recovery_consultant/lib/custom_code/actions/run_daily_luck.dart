// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:math' as math;

Future<dynamic> runDailyLuck(
  String? lastCheckDate,
  int? currentOrder,
  int? currentStreak,
) async {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final todayStr = "${today.year}-${today.month}-${today.day}";

  // ==========================================
  // 1. سيناريو لحظة إنشاء الطلب (أول مرة خالص)
  // ==========================================
  if (lastCheckDate == null || lastCheckDate.trim().isEmpty) {
    int initialOrder = currentOrder ?? 100;
    return {
      "hasChanged": true,
      "todayStr": todayStr,
      "newOrder": initialOrder,
      "newStreak": 0,
      "messageAr":
          "تم تقديم طلبك بنجاح! يتم تحديث ترتيبك يومياً بعد 12 منتصف الليل بناءً على نشاطك وتنفيذ الطلبات. تابعنا يومياً! 🚀",
      "messageEn":
          "Your request has been submitted successfully! Your queue updates daily after 12 AM based on activity. Check back daily! 🚀"
    };
  }

  // ==========================================
  // 2. معالجة وتنظيف تاريخ الفايربيس (سواء فيه وقت أم لا)
  // ==========================================
  DateTime? lastDate;
  try {
    // حاول يقرأ التاريخ بالوقت (مثل: 2026-07-26 18:22:20.158)
    lastDate = DateTime.tryParse(lastCheckDate.trim());

    // لو الصيغة كانت يدوية (مثل: 2026-7-26)
    if (lastDate == null) {
      final cleanStr = lastCheckDate.trim().split(' ')[0]; // إزالة الوقت إن وجد
      final parts = cleanStr.split('-');
      if (parts.length == 3) {
        lastDate = DateTime(
            int.parse(parts[0]), int.parse(parts[1]), int.parse(parts[2]));
      }
    }
  } catch (e) {
    lastDate = null;
  }

  // لو فشل في قراءة التاريخ خالص يعتبره أول يوم
  if (lastDate == null) {
    int initialOrder = currentOrder ?? 100;
    return {
      "hasChanged": true,
      "todayStr": todayStr,
      "newOrder": initialOrder,
      "newStreak": 0,
      "messageAr":
          "تم تقديم طلبك بنجاح! يتم تحديث ترتيبك يومياً بعد 12 منتصف الليل بناءً على نشاطك وتنفيذ الطلبات. تابعنا يومياً! 🚀",
      "messageEn":
          "Your request has been submitted successfully! Your queue updates daily after 12 AM based on activity. Check back daily! 🚀"
    };
  }

  // تجريد التاريخ من الساعات والدقائق للمقارنة بالأيام فقط
  final lastDateOnly = DateTime(lastDate.year, lastDate.month, lastDate.day);

  // ==========================================
  // 3. فحص هل فتح في نفس اليوم؟
  // ==========================================
  if (lastDateOnly.isAtSameMomentAs(today)) {
    return {
      "hasChanged": false,
      "todayStr": todayStr,
      "newOrder": currentOrder,
      "newStreak": currentStreak,
      "messageAr": "",
      "messageEn": ""
    };
  }

  // ==========================================
  // 4. حساب أيام الغياب بدقة
  // ==========================================
  int daysAbsent = today.difference(lastDateOnly).inDays;
  if (daysAbsent < 1) daysAbsent = 1;

  int changeValue = 0;
  int newOrder = currentOrder ?? 100;
  int streak = currentStreak ?? 0;
  bool isDecrease = true;

  final random = math.Random();

  // ==========================================
  // 5. تطبيق القواعد (التزام يومي VS عقاب الغياب)
  // ==========================================
  if (daysAbsent == 1) {
    // التزام يومي (فرق يوم واحد فقط)
    streak = (streak % 6) + 1;

    if (streak <= 3) {
      // أول 3 أيام: مكافأة وخصم (1 إلى 5) 🔥
      changeValue = 1 + random.nextInt(5);
      isDecrease = true;
    } else {
      // ثاني 3 أيام: زيادة وتنافس (6 إلى 10) ⚠️
      changeValue = 6 + random.nextInt(5);
      isDecrease = false;
    }
  } else {
    // 🚨 عقاب الغياب! (daysAbsent >= 2)
    streak = 0; // تصفير السلسلة
    isDecrease = false; // زيادة حتمية

    if (daysAbsent == 2) {
      changeValue = 11 + random.nextInt(5); // غياب يومين: زيادة من 11 لـ 15
    } else if (daysAbsent == 3) {
      changeValue = 15 + random.nextInt(6); // غياب 3 أيام: زيادة من 15 لـ 20
    } else {
      changeValue = 20 + random.nextInt(6); // غياب 4+ أيام: زيادة من 20 لـ 25
    }
  }

  // ==========================================
  // 6. تطبيق الأرقام على الدور
  // ==========================================
  if (isDecrease) {
    newOrder = newOrder - changeValue;
    if (newOrder < 1) newOrder = 1;
  } else {
    newOrder = newOrder + changeValue;
  }

  // ==========================================
  // 7. إعداد الرسائل
  // ==========================================
  String msgAr = "";
  String msgEn = "";

  if (isDecrease) {
    msgAr =
        "بشرى سارة! أنجز الفريق طلبات جديدة وتقدم ترتيبك بمقدار ($changeValue) خطوات. دورك الحالي: ($newOrder). 🔥";
    msgEn =
        "Great news! The team processed new orders and your queue advanced by ($changeValue) steps. Current position: ($newOrder). 🔥";
  } else {
    msgAr =
        "تنبيه! زاد ترتيبك بمقدار ($changeValue) خطوات لعدم اهتمامك بالمهمات ونشاط عملاء آخرين. دورك الحالي: ($newOrder). ⚠️";
    msgEn =
        "Alert! Your queue increased by ($changeValue) steps due to neglecting tasks and other clients' activity. Current position: ($newOrder). ⚠️";
  }

  return {
    "hasChanged": true,
    "todayStr": todayStr,
    "newOrder": newOrder,
    "newStreak": streak,
    "messageAr": msgAr,
    "messageEn": msgEn
  };
}
