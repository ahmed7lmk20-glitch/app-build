// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:async';
import 'package:google_mobile_ads/google_mobile_ads.dart';

// متغير عام في الذاكرة لتخزين كائن الإعلان
RewardedInterstitialAd? globalRewardedInterstitialAd;

Future<bool> loadRewardedInterstitialAd(BuildContext context) async {
  final Completer<bool> completer = Completer<bool>();

  // كود الإعلان الخاص بك
  String adUnitId = 'ca-app-pub-2079997928257932/7237983847';

  // تصفير الإعلان القديم
  globalRewardedInterstitialAd = null;

  // مؤقت أقصاه 7 ثوانٍ (7000 مللي ثانية)
  Timer timeoutTimer = Timer(const Duration(milliseconds: 7000), () {
    if (!completer.isCompleted) {
      completer.complete(false); // انتهى الوقت ولم يحمل الإعلان
    }
  });

  // طلب تحميل الإعلان
  RewardedInterstitialAd.load(
    adUnitId: adUnitId,
    request: const AdRequest(),
    rewardedInterstitialAdLoadCallback: RewardedInterstitialAdLoadCallback(
      onAdLoaded: (RewardedInterstitialAd ad) {
        timeoutTimer.cancel(); // إيقاف الـ Timeout فوراً
        globalRewardedInterstitialAd = ad;
        if (!completer.isCompleted) {
          completer.complete(true); // نجح التحميل فوراً
        }
      },
      onAdFailedToLoad: (LoadAdError error) {
        timeoutTimer.cancel();
        globalRewardedInterstitialAd = null;
        if (!completer.isCompleted) {
          completer.complete(false); // فشل التحميل
        }
      },
    ),
  );

  return completer.future;
}
