// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/custom_code/actions/index.dart';
import '/flutter_flow/custom_functions.dart';

// Imports للـ Firebase Auth والـ Firestore الخاصة بالتطبيق
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

Future<bool> deleteUserOrderBeforeDeleteAccount(BuildContext context) async {
  String currentLanguage = FFLocalizations.of(context).languageCode;
  bool isArabic = currentLanguage == 'ar';

  final currentUser = FirebaseAuth.instance.currentUser;
  if (currentUser == null) return false;

  final uid = currentUser.uid;

  // طريقة منفصلة للقيام بحذف بيانات المستخدم والطلبات من الفايرستور
  Future<bool> executeDataDeletion() async {
    try {
      final batch = FirebaseFirestore.instance.batch();

      final ordersSnapshot = await FirebaseFirestore.instance
          .collection('orders')
          .where('user_id', isEqualTo: uid)
          .get();

      for (var doc in ordersSnapshot.docs) {
        batch.delete(doc.reference);
      }

      final userDocRef =
          FirebaseFirestore.instance.collection('users').doc(uid);
      batch.delete(userDocRef);

      await batch.commit();

      FFAppState().adIndex = 0;
      FFAppState().myRewardedAd = null;

      await FirebaseAuth.instance.signOut();

      if (context.mounted) {
        _showSnackBar(
          context,
          isArabic
              ? 'تم حذف حسابك وجميع طلباتك بنجاح.'
              : 'Your account and orders have been deleted successfully.',
          const Color(0xFF16A34A),
        );

        context.goNamedAuth(
          'HomePage',
          context.mounted,
          ignoreRedirect: true,
        );
      }
      return true;
    } catch (e) {
      if (context.mounted) {
        _showSnackBar(
          context,
          isArabic
              ? 'حدث خطأ أثناء مسح البيانات.'
              : 'Error deleting user data.',
          const Color(0xFFDC2626),
        );
      }
      return false;
    }
  }

  // محاولة الحذف المباشرة أولاً
  try {
    await currentUser.delete();
    return await executeDataDeletion();
  } on FirebaseAuthException catch (e) {
    if (e.code == 'requires-recent-login') {
      // النافذة لتأكيد الباسورد في نص الشاشة بدون الخروج
      bool reauthSuccess =
          await _showReauthDialog(context, currentUser, isArabic);
      if (reauthSuccess) {
        try {
          await currentUser.delete();
          return await executeDataDeletion();
        } catch (e) {
          if (context.mounted) {
            _showSnackBar(
              context,
              isArabic
                  ? 'فشل حذف الحساب بعد التوثيق.'
                  : 'Failed to delete account after authentication.',
              const Color(0xFFDC2626),
            );
          }
          return false;
        }
      } else {
        return false;
      }
    } else {
      if (context.mounted) {
        _showSnackBar(
          context,
          isArabic
              ? 'لم يتم حذف الحساب، يرجى المحاولة مرة أخرى.'
              : 'Failed to delete account. Please try again.',
          const Color(0xFFDC2626),
        );
      }
      return false;
    }
  } catch (e) {
    return false;
  }
}

// -------------------------------------------------------------
// 🎨 نافذة الحوار لتأكيد بيانات الدخول
// -------------------------------------------------------------
Future<bool> _showReauthDialog(
    BuildContext context, User user, bool isArabic) async {
  final emailController = TextEditingController(text: user.email ?? '');
  final passwordController = TextEditingController();
  bool isLoading = false;
  String? errorMessage;

  return await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) {
          return StatefulBuilder(
            builder: (context, setState) {
              return AlertDialog(
                backgroundColor: const Color(0xFF1D2429),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.0),
                  side: const BorderSide(color: Color(0xFF39D2C0), width: 1),
                ),
                title: Text(
                  isArabic ? 'تأكيد هويتك للحذف' : 'Confirm Your Identity',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Readex Pro',
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        isArabic
                            ? 'لأسباب أمنية، أدخل كلمة المرور لتأكيد نهائي لحذف الحساب.'
                            : 'For security reasons, enter your password to confirm account deletion.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Color(0xFFA0A8B0),
                          fontFamily: 'Readex Pro',
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: emailController,
                        enabled: false,
                        style: const TextStyle(color: Colors.white70),
                        decoration: InputDecoration(
                          labelText: isArabic ? 'البريد الإلكتروني' : 'Email',
                          labelStyle: const TextStyle(color: Color(0xFFA0A8B0)),
                          filled: true,
                          fillColor: const Color(0xFF0F1316),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: passwordController,
                        obscureText: true,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          labelText: isArabic ? 'كلمة المرور' : 'Password',
                          labelStyle: const TextStyle(color: Color(0xFFA0A8B0)),
                          filled: true,
                          fillColor: const Color(0xFF0F1316),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            borderSide:
                                const BorderSide(color: Color(0xFF39D2C0)),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                      ),
                      if (errorMessage != null) ...[
                        const SizedBox(height: 8),
                        Text(
                          errorMessage!,
                          style: const TextStyle(
                              color: Color(0xFFFF5963), fontSize: 12),
                        ),
                      ],
                    ],
                  ),
                ),
                actionsAlignment: MainAxisAlignment.center,
                actions: [
                  TextButton(
                    onPressed: isLoading
                        ? null
                        : () => Navigator.pop(dialogContext, false),
                    child: Text(
                      isArabic ? 'إلغاء' : 'Cancel',
                      style: const TextStyle(color: Color(0xFFA0A8B0)),
                    ),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE53935),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                    onPressed: isLoading
                        ? null
                        : () async {
                            if (passwordController.text.trim().isEmpty) {
                              setState(() {
                                errorMessage = isArabic
                                    ? 'يرجى كتابة كلمة المرور'
                                    : 'Please enter password';
                              });
                              return;
                            }

                            setState(() {
                              isLoading = true;
                              errorMessage = null;
                            });

                            try {
                              AuthCredential credential =
                                  EmailAuthProvider.credential(
                                email: user.email!,
                                password: passwordController.text.trim(),
                              );
                              await user
                                  .reauthenticateWithCredential(credential);
                              if (dialogContext.mounted) {
                                Navigator.pop(dialogContext, true);
                              }
                            } on FirebaseAuthException catch (e) {
                              setState(() {
                                isLoading = false;
                                if (e.code == 'wrong-password' ||
                                    e.code == 'invalid-credential') {
                                  errorMessage = isArabic
                                      ? 'كلمة المرور غير صحيحة'
                                      : 'Incorrect password';
                                } else {
                                  errorMessage = isArabic
                                      ? 'حدث خطأ، تأكد من الاتصال بالنت'
                                      : 'Error occurred, check internet connection';
                                }
                              });
                            } catch (e) {
                              setState(() {
                                isLoading = false;
                                errorMessage = isArabic
                                    ? 'حدث خطأ ما'
                                    : 'An error occurred';
                              });
                            }
                          },
                    child: isLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2),
                          )
                        : Text(
                            isArabic ? 'تأكيد الحذف النهائي' : 'Confirm Delete',
                            style: const TextStyle(
                                color: Colors.white, fontFamily: 'Readex Pro'),
                          ),
                  ),
                ],
              );
            },
          );
        },
      ) ??
      false;
}

void _showSnackBar(BuildContext context, String message, Color color) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        message,
        style: const TextStyle(color: Colors.white, fontFamily: 'Readex Pro'),
      ),
      backgroundColor: color,
      duration: const Duration(seconds: 3),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
    ),
  );
}
