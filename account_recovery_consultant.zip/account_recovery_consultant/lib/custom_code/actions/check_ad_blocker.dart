// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// DO NOT REMOVE OR MODIFY THE CODE ABOVE THIS LINE

import 'package:google_mobile_ads/google_mobile_ads.dart';

Future<bool> checkAdBlocker(BuildContext context) async {
  bool isRewardedLoaded = false;

  // 1. القائمة الـ 5 بالترتيب
  List<String> adUnits = [
    'ca-app-pub-2079997928257932/1300529404', // كود 1
    'ca-app-pub-2079997928257932/5177647938', // كود 2
    'ca-app-pub-2079997928257932/2174979990', // كود 3
    'ca-app-pub-2079997928257932/2551484592', // كود 4
    'ca-app-pub-2079997928257932/1238402920', // كود 5
  ];

  // 2. تحديد الكود الحالي بناءً على العداد المحفوظ
  int currentIndex = FFAppState().adIndex ?? 0;

  if (currentIndex >= adUnits.length) {
    currentIndex = 0;
  }

  String currentAdUnitId = adUnits[currentIndex];

  // تصفير الإعلان القديم
  FFAppState().myRewardedAd = null;

  // 3. طلب تحميل الكود الحالي
  RewardedAd.load(
    adUnitId: currentAdUnitId,
    request: const AdRequest(),
    rewardedAdLoadCallback: RewardedAdLoadCallback(
      onAdLoaded: (RewardedAd ad) {
        FFAppState().myRewardedAd = ad;
        isRewardedLoaded = true;
      },
      onAdFailedToLoad: (LoadAdError error) {
        isRewardedLoaded = false;
        FFAppState().myRewardedAd = null;
      },
    ),
  );

  // 4. حلقة الانتظار (7 ثواني)
  int videoWaitLimit = 7000;
  int videoElapsed = 0;

  while (videoElapsed < videoWaitLimit) {
    if (isRewardedLoaded && FFAppState().myRewardedAd != null) {
      break;
    }
    await Future.delayed(const Duration(milliseconds: 100));
    videoElapsed += 100;
  }

  // 5. نقل العداد حتماً للكود التالي للمرة القادمة (من 0 لـ 4 ثم يعيد لـ 0)
  int nextIndex = (currentIndex + 1) % adUnits.length;
  FFAppState().adIndex = nextIndex;

  // 6. النتيجة
  if (isRewardedLoaded && FFAppState().myRewardedAd != null) {
    return true;
  } else {
    return false;
  }
}
