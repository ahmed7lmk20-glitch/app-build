// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:url_launcher/url_launcher.dart';

Future showRatingBottomSheet(
  BuildContext context,
  String messengerUrl,
) async {
  int selectedStars = 0; // يبدأ بـ 0 نجوم عشان يضطر يحدد بنفسه
  bool isArabic = Localizations.localeOf(context).languageCode == 'ar';

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (BuildContext ctx) {
      return StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Color(0xFF1E1E2C),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(25),
                topRight: Radius.circular(25),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      isArabic ? 'تقييم التجربة 🌟' : 'Rate Experience 🌟',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.grey),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  isArabic
                      ? 'ما رأيك في تجربة استرجاع الحساب؟'
                      : 'How was your experience with account recovery?',
                  style: const TextStyle(color: Colors.white70, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (index) {
                    return IconButton(
                      icon: Icon(
                        index < selectedStars
                            ? Icons.star_rounded
                            : Icons.star_outline_rounded,
                        color: Colors.amber,
                        size: 38,
                      ),
                      onPressed: () {
                        setState(() {
                          selectedStars = index + 1;
                        });
                      },
                    );
                  }),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6C5CE7),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: () async {
                      // التحقق من تحديد النجوم وإظهار نافذة تنبيه فوق الـ BottomSheet
                      if (selectedStars == 0) {
                        showDialog(
                          context: context,
                          builder: (BuildContext alertCtx) {
                            return AlertDialog(
                              backgroundColor: const Color(0xFF2A2A3D),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              title: Text(
                                isArabic ? 'تنبيه' : 'Notice',
                                style: const TextStyle(color: Colors.white),
                                textAlign:
                                    isArabic ? TextAlign.right : TextAlign.left,
                              ),
                              content: Text(
                                isArabic
                                    ? 'برجاء تحديد عدد النجوم أولاً للتقييم.'
                                    : 'Please select the number of stars first.',
                                style: const TextStyle(color: Colors.white70),
                                textAlign:
                                    isArabic ? TextAlign.right : TextAlign.left,
                              ),
                              actions: [
                                TextButton(
                                  child: Text(
                                    isArabic ? 'حسناً' : 'OK',
                                    style: const TextStyle(
                                        color: Color(0xFF6C5CE7)),
                                  ),
                                  onPressed: () => Navigator.pop(alertCtx),
                                ),
                              ],
                            );
                          },
                        );
                        return; // يمنع إكمال الكود حتى يحدد النجوم
                      }

                      Navigator.pop(context);

                      if (selectedStars == 5) {
                        final Uri storeUri = Uri.parse(
                            'https://play.google.com/store/apps/details?id=com.mycompany.masrawy');
                        if (await canLaunchUrl(storeUri)) {
                          await launchUrl(storeUri,
                              mode: LaunchMode.externalApplication);
                        }
                      } else {
                        showDialog(
                          context: context,
                          builder: (BuildContext dialogContext) {
                            return AlertDialog(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              title: Text(
                                isArabic ? 'تنبيه' : 'Notice',
                                textAlign:
                                    isArabic ? TextAlign.right : TextAlign.left,
                              ),
                              content: Text(
                                isArabic
                                    ? 'جاري تحويلك إلى تطبيق ماسنجر، اكتب شكوتك أو اقتراحك وسوف يتم الرد عليك فوراً.'
                                    : 'Redirecting you to Messenger. Please write your issue or suggestion and we will reply immediately.',
                                textAlign:
                                    isArabic ? TextAlign.right : TextAlign.left,
                              ),
                              actions: [
                                TextButton(
                                  child: Text(isArabic ? 'موافق' : 'OK'),
                                  onPressed: () async {
                                    Navigator.pop(dialogContext);
                                    final Uri messengerUri =
                                        Uri.parse(messengerUrl);
                                    if (await canLaunchUrl(messengerUri)) {
                                      await launchUrl(messengerUri,
                                          mode: LaunchMode.externalApplication);
                                    }
                                  },
                                ),
                              ],
                            );
                          },
                        );
                      }
                    },
                    child: Text(
                      isArabic ? 'إرسال التقييم' : 'Submit Rating',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
          );
        },
      );
    },
  );
}
