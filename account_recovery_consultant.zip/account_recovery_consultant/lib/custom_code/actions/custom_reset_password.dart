// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/custom_code/actions/index.dart';
import '/flutter_flow/custom_functions.dart';

import 'package:firebase_auth/firebase_auth.dart';

Future<bool> customResetPassword(
  BuildContext context,
  String email,
) async {
  // 1. معرفة لغة التطبيق الحالية (ar أو en)
  String currentLanguage = FFLocalizations.of(context).languageCode;
  bool isArabic = currentLanguage == 'ar';

  // 2. التحقق من أن الحقل ليس فارغاً
  if (email.trim().isEmpty) {
    String emptyEmailMsg = isArabic
        ? 'يرجى إدخال البريد الإلكتروني أولاً.'
        : 'Please enter your email address.';

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          emptyEmailMsg,
          style: const TextStyle(color: Colors.white, fontFamily: 'Readex Pro'),
        ),
        backgroundColor: const Color(0xFFDC2626), // أحمر
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
    );
    return false;
  }

  try {
    // 3. إرسال رابط استعادة كلمة المرور عبر Firebase Auth
    await FirebaseAuth.instance.sendPasswordResetEmail(
      email: email.trim(),
    );

    // 4. إظهار رسالة نجاح باللون الأخضر
    String successMsg = isArabic
        ? 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.'
        : 'Password reset link has been sent to your email.';

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          successMsg,
          style: const TextStyle(color: Colors.white, fontFamily: 'Readex Pro'),
        ),
        backgroundColor: const Color(0xFF16A34A), // أخضر نيون أنيق
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
    );

    return true;
  } on FirebaseAuthException catch (e) {
    // 5. التقاط الأخطاء وتحديد الرسالة المترجمة
    String message = '';

    switch (e.code) {
      case 'user-not-found':
        message = isArabic
            ? 'لم نجد حساباً مسجلاً بهذا البريد الإلكتروني.'
            : 'No user found with this email address.';
        break;

      case 'invalid-email':
        message = isArabic
            ? 'صيغة البريد الإلكتروني غير صحيحة.'
            : 'The email address is badly formatted.';
        break;

      case 'network-request-failed':
        message = isArabic
            ? 'يرجى التأكد من اتصالك بالإنترنت.'
            : 'Please check your internet connection.';
        break;

      default:
        message = isArabic
            ? 'حدث خطأ أثناء إرسال الرابط، يرجى المحاولة لاحقاً.'
            : 'An error occurred. Please try again later.';
        break;
    }

    // إظهار SnackBar أحمر عند الخطأ
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(color: Colors.white, fontFamily: 'Readex Pro'),
        ),
        backgroundColor: const Color(0xFFDC2626),
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
    );

    return false;
  } catch (e) {
    return false;
  }
}
