// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/custom_code/actions/index.dart';
import '/flutter_flow/custom_functions.dart';

import 'package:firebase_auth/firebase_auth.dart';

Future<bool> customSignUp(
  BuildContext context,
  String name,
  String email,
  String password,
  String confirmPassword,
) async {
  // 1. معرفة لغة التطبيق الحالية (ar أو en)
  String currentLanguage = FFLocalizations.of(context).languageCode;
  bool isArabic = currentLanguage == 'ar';

  // 2. فحص تطابق كلمة المرور مع تأكيد كلمة المرور أولاً
  if (password.trim() != confirmPassword.trim()) {
    String mismatchMessage = isArabic
        ? 'كلمة المرور وتأكيد كلمة المرور غير متطابقين.'
        : 'Passwords do not match.';

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          mismatchMessage,
          style: const TextStyle(color: Colors.white, fontFamily: 'Readex Pro'),
        ),
        backgroundColor: const Color(0xFFDC2626), // أحمر نيون أنيق
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
    );

    return false; // إيقاف العملية فوراً
  }

  try {
    // 3. إنشاء الحساب وتسجيل الدخول التلقائي في Firebase Auth
    UserCredential userCredential =
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password.trim(),
    );

    // 4. حفظ بيانات المستخدم والاسم في Firestore
    if (userCredential.user != null) {
      await userCredential.user!.updateDisplayName(name.trim());

      await FirebaseFirestore.instance
          .collection('users')
          .doc(userCredential.user!.uid)
          .set({
        'uid': userCredential.user!.uid,
        'display_name': name.trim(),
        'email': email.trim(),
        'created_time': FieldValue.serverTimestamp(),
      });
    }

    // نجح إنشاء الحساب وتأكيد الدخول
    return true;
  } on FirebaseAuthException catch (e) {
    // 5. التقاط أخطاء الفايربيس وتحديد الرسالة المترجمة
    String message = '';

    switch (e.code) {
      case 'email-already-in-use':
        message = isArabic
            ? 'هذا البريد الإلكتروني مسجل بالفعل، يرجى تسجيل الدخول.'
            : 'This email is already in use by another account.';
        break;

      case 'weak-password':
        message = isArabic
            ? 'كلمة المرور ضعيفة جداً، يرجى كتابة 6 خانات أو أكثر.'
            : 'The password provided is too weak.';
        break;

      case 'invalid-email':
        message = isArabic
            ? 'صيغة البريد الإلكتروني غير صحيحة.'
            : 'The email address is badly formatted.';
        break;

      case 'operation-not-allowed':
        message = isArabic
            ? 'إنشاء الحسابات بالبريد مغلق حالياً، تواصل مع الدعم.'
            : 'Email/password accounts are not enabled.';
        break;

      case 'network-request-failed':
        message = isArabic
            ? 'يرجى التأكد من اتصالك بالإنترنت.'
            : 'Please check your internet connection.';
        break;

      default:
        message = isArabic
            ? 'حدث خطأ أثناء إنشاء الحساب، يرجى المحاولة لاحقاً.'
            : 'An unexpected error occurred. Please try again.';
        break;
    }

    // إظهار SnackBar أحمر عند حدوث خطأ
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(color: Colors.white, fontFamily: 'Readex Pro'),
        ),
        backgroundColor: const Color(0xFFDC2626),
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
    );

    return false;
  } catch (e) {
    return false;
  }
}
