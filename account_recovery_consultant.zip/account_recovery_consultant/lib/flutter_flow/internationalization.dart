import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['ar', 'en'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? arText = '',
    String? enText = '',
  }) =>
      [arText, enText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // HomePage
  {
    '0zk4ufe2': {
      'ar': 'English',
      'en': 'English',
    },
    '6vxqybv2': {
      'ar': 'العربية',
      'en': 'العربية',
    },
    'igmx1tml': {
      'ar': 'أدخل البريد الإلكتروني',
      'en': 'Enter Email Address',
    },
    'q0g84h05': {
      'ar': 'أدخل كلمة المرور',
      'en': 'Enter Password',
    },
    'jovs6qn8': {
      'ar': 'تسجيل الدخول',
      'en': 'Log In',
    },
    'cwet2n4g': {
      'ar': '\"ليس لديك حساب؟ سجل الآن\"',
      'en': '\"Don\'t have an account? Register now\"',
    },
    '8cacnaf3': {
      'ar': 'نسيت كلمة المرور',
      'en': 'Forgot Password?',
    },
    'nsdbpcd0': {
      'ar': 'سجل حساب الان',
      'en': 'Register an Account Now',
    },
    'cjx0m15a': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // main_page
  {
    'c3kvvdlz': {
      'ar': 'العربية',
      'en': 'العربية',
    },
    'ntf4ehww': {
      'ar': 'English',
      'en': 'English',
    },
    'oe6ds9kf': {
      'ar': 'كيف نبدأ ؟',
      'en': 'How It Works ?',
    },
    'owdozmy5': {
      'ar': 'شرح بالفيديو',
      'en': 'Video Guide',
    },
    '57invdcb': {
      'ar': 'تقديم طلب',
      'en': 'Submit a Request',
    },
    '0y6ob52e': {
      'ar': 'متابعة الطلب',
      'en': 'Track Request',
    },
    'wsiy7mg5': {
      'ar': 'الشروط والخصوصية',
      'en': 'Security & Privacy',
    },
    'fcjlmam8': {
      'ar': 'تواصل معنا',
      'en': 'Contact Us',
    },
    'i57z82fs': {
      'ar': 'تسجيل الخروج',
      'en': 'Log Out',
    },
    '43qyomyw': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // sign_up_page
  {
    'afo75s9r': {
      'ar': 'أدخل الاسم',
      'en': 'Enter Name',
    },
    'xnerq4nq': {
      'ar': 'أدخل البريد الإلكتروني',
      'en': 'Enter Email Address',
    },
    '6frfs3id': {
      'ar': 'أدخل كلمة المرور',
      'en': 'Enter Password',
    },
    'qs1l42oh': {
      'ar': 'تأكيد كلمة المرور',
      'en': 'Confirm Password',
    },
    '15fuzbw1': {
      'ar':
          '\"بتسجيل حسابك، فإنك توافق على شروط الاستخدام و سياسة الخصوصية الخاصة بالتطبيق.\"',
      'en':
          '\"By registering your account, you agree to our Terms of Use and Privacy Policy.\"',
    },
    'movnowhh': {
      'ar': 'إنشاء حساب جديد',
      'en': 'Sign Up',
    },
    't69ec8l7': {
      'ar': 'لديك حساب بالفعل؟ تسجيل الدخول',
      'en': 'Already have an account? Log In',
    },
    '06yg102m': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // forgot_password_page
  {
    'kzfbetw2': {
      'ar': 'أدخل البريد الإلكتروني لاستعادة الحساب',
      'en': 'Enter Email to Recover Account',
    },
    'eploa5cl': {
      'ar': 'إرسال رابط استعادة الحساب',
      'en': 'Send Recovery Link',
    },
    'h7xznskq': {
      'ar': 'العودة لتسجيل الدخول',
      'en': 'Back to Log In',
    },
    '6wlzy1op': {
      'ar': 'أدخل البريد الإلكتروني لاستعادة الحساب ',
      'en': 'Enter Email to Recover Account',
    },
    'xwpgctqo': {
      'ar': 'Please choose an option from the dropdown',
      'en': 'Please choose an option from the dropdown',
    },
    'rz3ux244': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // create_order_page
  {
    'ir49vebu': {
      'ar':
          'يرجى التأكد من البيانات جيداً، سوف يتم التواصل معك بمجرد وصول ترتيب دورك إلى رقم 1. فقط قدم الطلب وانتظر دورك.',
      'en':
          'Please ensure your details are correct. You will be contacted once your turn reaches number 1. Just submit the request and wait for your turn.',
    },
    'gxw9cs1b': {
      'ar': 'نوع الحساب',
      'en': 'Account Type',
    },
    '0ent7ajs': {
      'ar': 'Facebook',
      'en': 'Facebook',
    },
    'i27gzw47': {
      'ar': 'WhatsApp',
      'en': 'WhatsApp',
    },
    'bi7d0v0e': {
      'ar': 'Snapchat',
      'en': 'Snapchat',
    },
    'fent4m4r': {
      'ar': 'Instagram',
      'en': 'Instagram',
    },
    'ix8lnhjc': {
      'ar': 'TikTok',
      'en': 'TikTok',
    },
    'x47pcgqy': {
      'ar': 'PUBG',
      'en': 'PUBG',
    },
    'w7gvw8up': {
      'ar': 'X',
      'en': 'X',
    },
    'wcsyozoe': {
      'ar': 'gmail',
      'en': 'gmail',
    },
    'c8ipetuw': {
      'ar': 'Telegram',
      'en': 'Telegram',
    },
    'z5jm9q5p': {
      'ar': 'Discord',
      'en': 'Discord',
    },
    'kvko3mkq': {
      'ar': 'PayPal',
      'en': 'PayPal',
    },
    'wuzcp9ry': {
      'ar': 'iCloud',
      'en': 'iCloud',
    },
    '21iid052': {
      'ar': 'Roblox',
      'en': 'Roblox',
    },
    'aqmu2e58': {
      'ar': 'Free Fire',
      'en': 'Free Fire',
    },
    'ukaclg2k': {
      'ar': 'صاحب الحساب او وسيط',
      'en': 'Account Owner or Mediator',
    },
    'jwwf61y7': {
      'ar': 'صاحب الحساب',
      'en': 'Account Owner',
    },
    'k1elmu1h': {
      'ar': 'وسيط',
      'en': 'Mediator',
    },
    '790ywbwb': {
      'ar': 'اكتب اسمك',
      'en': 'Enter Your Name',
    },
    'ihfkkkmk': {
      'ar': 'البريد الالكترونى',
      'en': 'Email Address',
    },
    'fokffuay': {
      'ar': 'رقم الموبايل',
      'en': 'Mobile Number',
    },
    '3c7o6pbk': {
      'ar': '',
      'en': '',
    },
    'f86znzta': {
      'ar': 'اكتب اسم الحساب (اختيارى) ',
      'en': 'Enter Account Name (Optional)',
    },
    'mmzyg579': {
      'ar': '',
      'en': '',
    },
    'qczgr0pz': {
      'ar': 'اضف رقم هاتف او رابط الحساب (اختيارى)',
      'en': 'Add Phone Number or Account Link (Optional)',
    },
    'l8f10ruy': {
      'ar': 'الدوله_الجنسيه',
      'en': 'Country / Nationality',
    },
    'pe7fm8kl': {
      'ar': 'طريقة الاتصال المفضلة (اكتب التطبيق + الرقم أو الرابط)',
      'en': 'Preferred Contact Method (App + Number or Link)',
    },
    '03abt9bx': {
      'ar':
          'عذراً، لا يمكنك تقديم طلب جديد إلا بعد انتهاء العمل على الطلب الحالي أو حذفه',
      'en':
          'Sorry, you cannot submit a new request until the current request is completed or deleted.',
    },
    '2xlhtpm4': {
      'ar': 'قدم الطلب الان',
      'en': 'Submit Request Now',
    },
    'qgool4c1': {
      'ar': 'اكتب اسمك is required',
      'en': 'Name is required',
    },
    'ctucfokn': {
      'ar': 'Please choose an option from the dropdown',
      'en': 'Please choose an option from the dropdown',
    },
    '78s6vtlc': {
      'ar': 'البريد الالكترونى is required',
      'en': 'Email is required',
    },
    's8lwqe4c': {
      'ar': 'Please choose an option from the dropdown',
      'en': 'Please choose an option from the dropdown',
    },
    'kxbyghx6': {
      'ar': 'رقم الموبايل is required',
      'en': 'Mobile number is required',
    },
    'vjqr24by': {
      'ar': 'Please choose an option from the dropdown',
      'en': 'Please choose an option from the dropdown',
    },
    '1qn7rxvj': {
      'ar': 'الدوله_الجنسيه is required',
      'en': 'Country / Nationality is required',
    },
    '5mzt5dmz': {
      'ar': 'Please choose an option from the dropdown',
      'en': 'Please choose an option from the dropdown',
    },
    'spgkwpw4': {
      'ar': 'سبب المشكله is required',
      'en': 'Reason for the problem is required',
    },
    '0qjfjo21': {
      'ar': 'Please choose an option from the dropdown',
      'en': 'Please choose an option from the dropdown',
    },
    'vpnw0mpi': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // my_orders_page
  {
    '0izk80qn': {
      'ar': 'حذف الطلب',
      'en': 'Delete Request',
    },
    '8pqh0106': {
      'ar':
          'سنتصل بك عندما يصبح دورك ( 1 ) 📞\n🔄 يتجدد الترتيب يومياً 12 مساءً',
      'en':
          'We will call when queue is ( 1 ) 📞\n🔄 Queue updates daily at 12 PM',
    },
    'oizbedf1': {
      'ar': '🎯 نفّذ المهمات عشان طلبك يخلص أسرع!',
      'en': '🎯 Complete tasks to process your request faster!',
    },
    '6qintmku': {
      'ar': ' أكمل المهمة الكبرى واخصم (100)دوراً من ترتيبك',
      'en': ' Complete the Mega Task & Skip (100) Places',
    },
    'kdgf2jre': {
      'ar': 'الشكاوى والدعم الفني',
      'en': 'Support & Complaints',
    },
    'i6u5ydak': {
      'ar': 'لا توجد طلبات قائمة حالياً 📋',
      'en': 'No current orders found 📋',
    },
    'y63h2xrw': {
      'ar': 'تقديم طلب جديد ➕',
      'en': 'Create New Order ➕',
    },
    'ssg08rgu': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // policies_page
  {
    'flvehv4e': {
      'ar': 'حذف الحساب',
      'en': 'Delete Account',
    },
    'alfhqeox': {
      'ar': 'اداره',
      'en': 'Admin',
    },
    'lyi3uhgj': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // ExplainerPage
  {
    's3alkp7z': {
      'ar': 'الرجوع إلى الصفحة الرئيسية',
      'en': 'Back to Home Page',
    },
    'xwim02ws': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // PublishGuidePage
  {
    '9jd6bvfj': {
      'ar': 'الانتقال إلى المهمة',
      'en': 'Go to Task',
    },
    'h8h5qlj6': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // SubmitTaskPage
  {
    'ahev5uwm': {
      'ar': 'انـسـخ الـنـص',
      'en': 'Copy Text',
    },
    'at9if8qa': {
      'ar': 'تحميل الصوره',
      'en': 'Upload Image',
    },
    'mrivmex4': {
      'ar': 'تم تنفيذ هذه المهمة بنجاح والحصول على المكافأة!',
      'en': 'This task was successfully executed, and the reward was granted!',
    },
    'cmkgiout': {
      'ar': 'شاهد اعلان ونفذ المهمه',
      'en': 'Watch an Ad and Execute Task',
    },
    'qyrryvg7': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // admin_dashboard
  {
    'b6ahqwxv': {
      'ar': 'لوحه الاداره',
      'en': 'لوحه الاداره',
    },
    '3ollu4o1': {
      'ar': 'اكتب نص الإشعار هنا....',
      'en': 'اكتب نص الإشعار هنا....',
    },
    '1cq0s1p4': {
      'ar': 'إرسال إشعار للكل',
      'en': 'إرسال إشعار للكل',
    },
    'd1if0wdf': {
      'ar': 'حذف الخاملين ',
      'en': 'حذف الخاملين ',
    },
    'ry2crf0k': {
      'ar': 'تغيير قيم',
      'en': 'تغيير قيم',
    },
    '7hypvb8j': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // order_details
  {
    'yx8o2ay7': {
      'ar': 'مراجعه طلب العميل',
      'en': 'مراجعه طلب العميل',
    },
    '7t40ebfj': {
      'ar': 'اكتب هنا نص الاشعار الفردى للعميل',
      'en': 'اكتب هنا نص الاشعار الفردى للعميل',
    },
    'ayehz06l': {
      'ar': 'ارسل الاشعار الان',
      'en': 'ارسل الاشعار الان',
    },
    '59bymrbi': {
      'ar': 'آخر تسجيل دخول:',
      'en': 'آخر تسجيل دخول:',
    },
    'sgnzm885': {
      'ar': 'نوع الحساب',
      'en': 'نوع الحساب',
    },
    'y9pae4o5': {
      'ar': 'نوع الطلب',
      'en': 'نوع الطلب',
    },
    '9s9l32dn': {
      'ar': 'اسم العميل',
      'en': 'اسم العميل',
    },
    '8r3nhzer': {
      'ar': 'رقم الموبايل',
      'en': 'رقم الموبايل',
    },
    '2clvhgga': {
      'ar': 'بريد تسجيل الدخول',
      'en': 'بريد تسجيل الدخول',
    },
    'ripnm9vy': {
      'ar': 'بريد الاتصال تقديم الطلب',
      'en': 'بريد الاتصال تقديم الطلب',
    },
    '3cvo7kqw': {
      'ar': 'الجنسيه',
      'en': 'الجنسيه',
    },
    '9ld30w0k': {
      'ar': 'طريقه الاتصال',
      'en': 'طريقه الاتصال',
    },
    'qt44akyk': {
      'ar': 'اسم الحساب المراد فتحه ',
      'en': 'اسم الحساب المراد فتحه ',
    },
    'bbcafoxb': {
      'ar': 'رابط الحساب المراد فتحه',
      'en': 'رابط الحساب المراد فتحه',
    },
    'b30xa6qb': {
      'ar': 'TextField',
      'en': 'TextField',
    },
    '63mdor43': {
      'ar': 'تغيير دور الطلب',
      'en': 'تغيير دور الطلب',
    },
    'hip7qjj8': {
      'ar': 'حذف الطلب',
      'en': 'حذف الطلب',
    },
    'jjvmii0a': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // AdminPanel
  {
    'au1rsn5t': {
      'ar': 'صفحه تغيير مهمه النشر',
      'en': 'صفحه تغيير مهمه النشر',
    },
    'p2le9xvf': {
      'ar': 'نص النسخ',
      'en': 'نص النسخ',
    },
    '1befao7m': {
      'ar': 'تحديث النص نسخ المهمه',
      'en': 'تحديث النص نسخ المهمه',
    },
    '3pwvboip': {
      'ar': 'رابط الصوره',
      'en': 'رابط الصوره',
    },
    'n48upifp': {
      'ar': 'تحديث الصوره نسخ المهمه',
      'en': 'تحديث الصوره نسخ المهمه',
    },
    'hjgwoxcx': {
      'ar': 'رابط المتجر',
      'en': 'رابط المتجر',
    },
    '3abqf02y': {
      'ar': 'تحديث رابط الشكاوى والاقتراحات',
      'en': 'تحديث رابط الشكاوى والاقتراحات',
    },
    'hdlpdj8r': {
      'ar': 'أدخل رابط الفيديو الجديد هنا',
      'en': 'أدخل رابط الفيديو الجديد هنا',
    },
    '10lvn9v0': {
      'ar': 'تغيير رابط الفديو',
      'en': 'تغيير رابط الفديو',
    },
    '1dx867q2': {
      'ar': 'TextField',
      'en': 'TextField',
    },
    '8a330tba': {
      'ar': 'تغيير السياسات والخصوصيه',
      'en': 'تغيير السياسات والخصوصيه',
    },
    'hdbttzfb': {
      'ar': 'TextField',
      'en': 'TextField',
    },
    'dmbxztqx': {
      'ar': 'تغيير الشرح البسيط',
      'en': 'تغيير الشرح البسيط',
    },
    'mzrp5wej': {
      'ar': 'TextField',
      'en': 'TextField',
    },
    'xu7b39h8': {
      'ar': 'تغيير نص المهمه',
      'en': 'تغيير نص المهمه',
    },
    'l57tlaol': {
      'ar': 'TextField',
      'en': 'TextField',
    },
    'j90kr7rm': {
      'ar': 'تغيير عدد مرات ظهور الاعلان 1000 خصم',
      'en': 'تغيير عدد مرات ظهور الاعلان 1000 خصم',
    },
    'fo3rp6b9': {
      'ar': 'ربط الغه الانجليزيه',
      'en': 'ربط الغه الانجليزيه',
    },
    '03gl839m': {
      'ar': 'TextField',
      'en': 'TextField',
    },
    'st632ih1': {
      'ar': 'مهمه النسخ انجليزى',
      'en': 'مهمه النسخ انجليزى',
    },
    'g28twsv2': {
      'ar': 'TextField',
      'en': 'TextField',
    },
    '8d2nti1j': {
      'ar': 'تغيير حقل الصوره للعرض والتحميل',
      'en': 'تغيير حقل الصوره للعرض والتحميل',
    },
    'b4qxje17': {
      'ar': 'TextField',
      'en': 'TextField',
    },
    'h5tuua38': {
      'ar': 'سياسات وخصوصيه انجليزى',
      'en': 'سياسات وخصوصيه انجليزى',
    },
    'hek25ls6': {
      'ar': 'TextField',
      'en': 'TextField',
    },
    'rhvjuc4h': {
      'ar': 'شرح التطبيق انجلش',
      'en': 'شرح التطبيق انجلش',
    },
    'nmoo2vvj': {
      'ar': 'TextField',
      'en': 'TextField',
    },
    '01vzg1i2': {
      'ar': 'شرح خطوات المهمه',
      'en': 'شرح خطوات المهمه',
    },
    'fj92eacy': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // video_guide_page
  {
    'bzhl7j3z': {
      'ar': 'قدم طلب الان',
      'en': 'Submit a Request Now',
    },
    'oiar03pz': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // InactiveOrdersPage
  {
    'h5wd8h8j': {
      'ar': 'حذف الحسابات والطلبات الخاملة دفعة واحدة',
      'en': 'حذف الحسابات والطلبات الخاملة دفعة واحدة',
    },
    '7yt4kp57': {
      'ar': 'تصفيه الطلبات الخامله',
      'en': 'تصفيه الطلبات الخامله',
    },
    'vjy92snh': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // admin_stats_page
  {
    'reqfm2vs': {
      'ar': 'لوحه الاداره',
      'en': 'لوحه الاداره',
    },
    'sapi2l4w': {
      'ar': 'احصائيات الحسابات',
      'en': '',
    },
    '3i6fw891': {
      'ar': 'احصائيات الطلبات',
      'en': '',
    },
    'invhqmrg': {
      'ar': 'احصائيات الطلبات الخامله',
      'en': '',
    },
    'tncb1ajr': {
      'ar': 'انتقل لصفحه حذف الطلبات',
      'en': '',
    },
    '4glp26kz': {
      'ar': 'لوحه الاداره الشامله',
      'en': '',
    },
    '788ui4md': {
      'ar': 'Home',
      'en': 'Home',
    },
  },
  // Miscellaneous
  {
    'mq1xm6ad': {
      'ar': '',
      'en': '',
    },
    '6ea51tz0': {
      'ar': '',
      'en': '',
    },
    'bvqzkhxg': {
      'ar': '',
      'en': '',
    },
    '7b52miqd': {
      'ar': '',
      'en': '',
    },
    '9znh1r3s': {
      'ar': '',
      'en': '',
    },
    'qfyvgv6l': {
      'ar': '',
      'en': '',
    },
    'exi0glmz': {
      'ar': '',
      'en': '',
    },
    'ly685yje': {
      'ar': '',
      'en': '',
    },
    'r4zyxgip': {
      'ar': '',
      'en': '',
    },
    'g4q5k77d': {
      'ar': '',
      'en': '',
    },
    'ddr7dyhp': {
      'ar': '',
      'en': '',
    },
    'whwj584i': {
      'ar': '',
      'en': '',
    },
    '3msncbt9': {
      'ar': '',
      'en': '',
    },
    'lljlim4g': {
      'ar': '',
      'en': '',
    },
    'dvqp8kmc': {
      'ar': '',
      'en': '',
    },
    'mir1mml5': {
      'ar': '',
      'en': '',
    },
    'qp817orf': {
      'ar': '',
      'en': '',
    },
    'ldkmkcai': {
      'ar': '',
      'en': '',
    },
    'fs7lrq2m': {
      'ar': '',
      'en': '',
    },
    'pxnlw875': {
      'ar': '',
      'en': '',
    },
    'gluedcx9': {
      'ar': '',
      'en': '',
    },
    '6yxdq1ki': {
      'ar': '',
      'en': '',
    },
    'gi43txfb': {
      'ar': '',
      'en': '',
    },
    'y4chy5gk': {
      'ar': '',
      'en': '',
    },
    '1ojcaowu': {
      'ar': '',
      'en': '',
    },
    '1nni1mig': {
      'ar': '',
      'en': '',
    },
    'xfex0s5h': {
      'ar': '',
      'en': '',
    },
  },
].reduce((a, b) => a..addAll(b));
