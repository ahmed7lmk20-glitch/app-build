import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDzKuPRcqDxJHRRi971j7WGoYRxb69-Grk",
            authDomain: "masrawy-21c13.firebaseapp.com",
            projectId: "masrawy-21c13",
            storageBucket: "masrawy-21c13.firebasestorage.app",
            messagingSenderId: "341254317584",
            appId: "1:341254317584:web:984d3fb25eb07a57f64c95",
            measurementId: "G-H08RGQ0G02"));
  } else {
    await Firebase.initializeApp();
  }
}
