import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OrdersRecord extends FirestoreRecord {
  OrdersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "client_name" field.
  String? _clientName;
  String get clientName => _clientName ?? '';
  bool hasClientName() => _clientName != null;

  // "platform" field.
  String? _platform;
  String get platform => _platform ?? '';
  bool hasPlatform() => _platform != null;

  // "account_type" field.
  String? _accountType;
  String get accountType => _accountType ?? '';
  bool hasAccountType() => _accountType != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "queue_number" field.
  int? _queueNumber;
  int get queueNumber => _queueNumber ?? 0;
  bool hasQueueNumber() => _queueNumber != null;

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "user_id" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "ad_count" field.
  int? _adCount;
  int get adCount => _adCount ?? 0;
  bool hasAdCount() => _adCount != null;

  // "block_time" field.
  DateTime? _blockTime;
  DateTime? get blockTime => _blockTime;
  bool hasBlockTime() => _blockTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "problem_reason" field.
  String? _problemReason;
  String get problemReason => _problemReason ?? '';
  bool hasProblemReason() => _problemReason != null;

  // "user_email" field.
  String? _userEmail;
  String get userEmail => _userEmail ?? '';
  bool hasUserEmail() => _userEmail != null;

  // "client_nationality" field.
  String? _clientNationality;
  String get clientNationality => _clientNationality ?? '';
  bool hasClientNationality() => _clientNationality != null;

  // "account_name" field.
  String? _accountName;
  String get accountName => _accountName ?? '';
  bool hasAccountName() => _accountName != null;

  // "account_link" field.
  String? _accountLink;
  String get accountLink => _accountLink ?? '';
  bool hasAccountLink() => _accountLink != null;

  // "streak" field.
  int? _streak;
  int get streak => _streak ?? 0;
  bool hasStreak() => _streak != null;

  void _initializeFields() {
    _clientName = snapshotData['client_name'] as String?;
    _platform = snapshotData['platform'] as String?;
    _accountType = snapshotData['account_type'] as String?;
    _status = snapshotData['status'] as String?;
    _queueNumber = castToType<int>(snapshotData['queue_number']);
    _createdAt = snapshotData['created_at'] as DateTime?;
    _userId = snapshotData['user_id'] as String?;
    _adCount = castToType<int>(snapshotData['ad_count']);
    _blockTime = snapshotData['block_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _problemReason = snapshotData['problem_reason'] as String?;
    _userEmail = snapshotData['user_email'] as String?;
    _clientNationality = snapshotData['client_nationality'] as String?;
    _accountName = snapshotData['account_name'] as String?;
    _accountLink = snapshotData['account_link'] as String?;
    _streak = castToType<int>(snapshotData['streak']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('orders');

  static Stream<OrdersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OrdersRecord.fromSnapshot(s));

  static Future<OrdersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => OrdersRecord.fromSnapshot(s));

  static OrdersRecord fromSnapshot(DocumentSnapshot snapshot) => OrdersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OrdersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OrdersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OrdersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OrdersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOrdersRecordData({
  String? clientName,
  String? platform,
  String? accountType,
  String? status,
  int? queueNumber,
  DateTime? createdAt,
  String? userId,
  int? adCount,
  DateTime? blockTime,
  String? phoneNumber,
  String? problemReason,
  String? userEmail,
  String? clientNationality,
  String? accountName,
  String? accountLink,
  int? streak,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'client_name': clientName,
      'platform': platform,
      'account_type': accountType,
      'status': status,
      'queue_number': queueNumber,
      'created_at': createdAt,
      'user_id': userId,
      'ad_count': adCount,
      'block_time': blockTime,
      'phone_number': phoneNumber,
      'problem_reason': problemReason,
      'user_email': userEmail,
      'client_nationality': clientNationality,
      'account_name': accountName,
      'account_link': accountLink,
      'streak': streak,
    }.withoutNulls,
  );

  return firestoreData;
}

class OrdersRecordDocumentEquality implements Equality<OrdersRecord> {
  const OrdersRecordDocumentEquality();

  @override
  bool equals(OrdersRecord? e1, OrdersRecord? e2) {
    return e1?.clientName == e2?.clientName &&
        e1?.platform == e2?.platform &&
        e1?.accountType == e2?.accountType &&
        e1?.status == e2?.status &&
        e1?.queueNumber == e2?.queueNumber &&
        e1?.createdAt == e2?.createdAt &&
        e1?.userId == e2?.userId &&
        e1?.adCount == e2?.adCount &&
        e1?.blockTime == e2?.blockTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.problemReason == e2?.problemReason &&
        e1?.userEmail == e2?.userEmail &&
        e1?.clientNationality == e2?.clientNationality &&
        e1?.accountName == e2?.accountName &&
        e1?.accountLink == e2?.accountLink &&
        e1?.streak == e2?.streak;
  }

  @override
  int hash(OrdersRecord? e) => const ListEquality().hash([
        e?.clientName,
        e?.platform,
        e?.accountType,
        e?.status,
        e?.queueNumber,
        e?.createdAt,
        e?.userId,
        e?.adCount,
        e?.blockTime,
        e?.phoneNumber,
        e?.problemReason,
        e?.userEmail,
        e?.clientNationality,
        e?.accountName,
        e?.accountLink,
        e?.streak
      ]);

  @override
  bool isValidKey(Object? o) => o is OrdersRecord;
}
