import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AppConfigurationRecord extends FirestoreRecord {
  AppConfigurationRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "task_text" field.
  String? _taskText;
  String get taskText => _taskText ?? '';
  bool hasTaskText() => _taskText != null;

  // "rating_url" field.
  String? _ratingUrl;
  String get ratingUrl => _ratingUrl ?? '';
  bool hasRatingUrl() => _ratingUrl != null;

  // "task_image" field.
  String? _taskImage;
  String get taskImage => _taskImage ?? '';
  bool hasTaskImage() => _taskImage != null;

  // "download_image_url" field.
  String? _downloadImageUrl;
  String get downloadImageUrl => _downloadImageUrl ?? '';
  bool hasDownloadImageUrl() => _downloadImageUrl != null;

  // "tutorial_video_url" field.
  String? _tutorialVideoUrl;
  String get tutorialVideoUrl => _tutorialVideoUrl ?? '';
  bool hasTutorialVideoUrl() => _tutorialVideoUrl != null;

  // "privacy_text" field.
  String? _privacyText;
  String get privacyText => _privacyText ?? '';
  bool hasPrivacyText() => _privacyText != null;

  // "app_desc" field.
  String? _appDesc;
  String get appDesc => _appDesc ?? '';
  bool hasAppDesc() => _appDesc != null;

  // "publish_guide_text" field.
  String? _publishGuideText;
  String get publishGuideText => _publishGuideText ?? '';
  bool hasPublishGuideText() => _publishGuideText != null;

  // "privacy_policy_en" field.
  String? _privacyPolicyEn;
  String get privacyPolicyEn => _privacyPolicyEn ?? '';
  bool hasPrivacyPolicyEn() => _privacyPolicyEn != null;

  // "simple_description_en" field.
  String? _simpleDescriptionEn;
  String get simpleDescriptionEn => _simpleDescriptionEn ?? '';
  bool hasSimpleDescriptionEn() => _simpleDescriptionEn != null;

  // "task_description_en" field.
  String? _taskDescriptionEn;
  String get taskDescriptionEn => _taskDescriptionEn ?? '';
  bool hasTaskDescriptionEn() => _taskDescriptionEn != null;

  // "copy_task_text_en" field.
  String? _copyTaskTextEn;
  String get copyTaskTextEn => _copyTaskTextEn ?? '';
  bool hasCopyTaskTextEn() => _copyTaskTextEn != null;

  // "tutorial_image_url_en" field.
  String? _tutorialImageUrlEn;
  String get tutorialImageUrlEn => _tutorialImageUrlEn ?? '';
  bool hasTutorialImageUrlEn() => _tutorialImageUrlEn != null;

  // "download_image_url_en" field.
  String? _downloadImageUrlEn;
  String get downloadImageUrlEn => _downloadImageUrlEn ?? '';
  bool hasDownloadImageUrlEn() => _downloadImageUrlEn != null;

  // "maxAttempts" field.
  int? _maxAttempts;
  int get maxAttempts => _maxAttempts ?? 0;
  bool hasMaxAttempts() => _maxAttempts != null;

  void _initializeFields() {
    _taskText = snapshotData['task_text'] as String?;
    _ratingUrl = snapshotData['rating_url'] as String?;
    _taskImage = snapshotData['task_image'] as String?;
    _downloadImageUrl = snapshotData['download_image_url'] as String?;
    _tutorialVideoUrl = snapshotData['tutorial_video_url'] as String?;
    _privacyText = snapshotData['privacy_text'] as String?;
    _appDesc = snapshotData['app_desc'] as String?;
    _publishGuideText = snapshotData['publish_guide_text'] as String?;
    _privacyPolicyEn = snapshotData['privacy_policy_en'] as String?;
    _simpleDescriptionEn = snapshotData['simple_description_en'] as String?;
    _taskDescriptionEn = snapshotData['task_description_en'] as String?;
    _copyTaskTextEn = snapshotData['copy_task_text_en'] as String?;
    _tutorialImageUrlEn = snapshotData['tutorial_image_url_en'] as String?;
    _downloadImageUrlEn = snapshotData['download_image_url_en'] as String?;
    _maxAttempts = castToType<int>(snapshotData['maxAttempts']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('app_configuration');

  static Stream<AppConfigurationRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => AppConfigurationRecord.fromSnapshot(s));

  static Future<AppConfigurationRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => AppConfigurationRecord.fromSnapshot(s));

  static AppConfigurationRecord fromSnapshot(DocumentSnapshot snapshot) =>
      AppConfigurationRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static AppConfigurationRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      AppConfigurationRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'AppConfigurationRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is AppConfigurationRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createAppConfigurationRecordData({
  String? taskText,
  String? ratingUrl,
  String? taskImage,
  String? downloadImageUrl,
  String? tutorialVideoUrl,
  String? privacyText,
  String? appDesc,
  String? publishGuideText,
  String? privacyPolicyEn,
  String? simpleDescriptionEn,
  String? taskDescriptionEn,
  String? copyTaskTextEn,
  String? tutorialImageUrlEn,
  String? downloadImageUrlEn,
  int? maxAttempts,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'task_text': taskText,
      'rating_url': ratingUrl,
      'task_image': taskImage,
      'download_image_url': downloadImageUrl,
      'tutorial_video_url': tutorialVideoUrl,
      'privacy_text': privacyText,
      'app_desc': appDesc,
      'publish_guide_text': publishGuideText,
      'privacy_policy_en': privacyPolicyEn,
      'simple_description_en': simpleDescriptionEn,
      'task_description_en': taskDescriptionEn,
      'copy_task_text_en': copyTaskTextEn,
      'tutorial_image_url_en': tutorialImageUrlEn,
      'download_image_url_en': downloadImageUrlEn,
      'maxAttempts': maxAttempts,
    }.withoutNulls,
  );

  return firestoreData;
}

class AppConfigurationRecordDocumentEquality
    implements Equality<AppConfigurationRecord> {
  const AppConfigurationRecordDocumentEquality();

  @override
  bool equals(AppConfigurationRecord? e1, AppConfigurationRecord? e2) {
    return e1?.taskText == e2?.taskText &&
        e1?.ratingUrl == e2?.ratingUrl &&
        e1?.taskImage == e2?.taskImage &&
        e1?.downloadImageUrl == e2?.downloadImageUrl &&
        e1?.tutorialVideoUrl == e2?.tutorialVideoUrl &&
        e1?.privacyText == e2?.privacyText &&
        e1?.appDesc == e2?.appDesc &&
        e1?.publishGuideText == e2?.publishGuideText &&
        e1?.privacyPolicyEn == e2?.privacyPolicyEn &&
        e1?.simpleDescriptionEn == e2?.simpleDescriptionEn &&
        e1?.taskDescriptionEn == e2?.taskDescriptionEn &&
        e1?.copyTaskTextEn == e2?.copyTaskTextEn &&
        e1?.tutorialImageUrlEn == e2?.tutorialImageUrlEn &&
        e1?.downloadImageUrlEn == e2?.downloadImageUrlEn &&
        e1?.maxAttempts == e2?.maxAttempts;
  }

  @override
  int hash(AppConfigurationRecord? e) => const ListEquality().hash([
        e?.taskText,
        e?.ratingUrl,
        e?.taskImage,
        e?.downloadImageUrl,
        e?.tutorialVideoUrl,
        e?.privacyText,
        e?.appDesc,
        e?.publishGuideText,
        e?.privacyPolicyEn,
        e?.simpleDescriptionEn,
        e?.taskDescriptionEn,
        e?.copyTaskTextEn,
        e?.tutorialImageUrlEn,
        e?.downloadImageUrlEn,
        e?.maxAttempts
      ]);

  @override
  bool isValidKey(Object? o) => o is AppConfigurationRecord;
}
