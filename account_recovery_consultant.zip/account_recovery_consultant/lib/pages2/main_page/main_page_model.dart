import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_ad_banner.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'main_page_widget.dart' show MainPageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class MainPageModel extends FlutterFlowModel<MainPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Firestore Query - Query a collection] action in main_page widget.
  UsersRecord? checkUserDoc;
  // Stores action output result for [Custom Action - loadRewardedInterstitialAd] action in Button widget.
  bool? isReady;
  // Stores action output result for [Custom Action - showRewardedInterstitialAd] action in Button widget.
  bool? gotReward;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  OrdersRecord? userOrderDoc;
  // Stores action output result for [Custom Action - loadRewardedInterstitialAd] action in Button widget.
  bool? isReady2;
  // Stores action output result for [Custom Action - showRewardedInterstitialAd] action in Button widget.
  bool? gotReward2;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  OrdersRecord? userOrderDoc2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
