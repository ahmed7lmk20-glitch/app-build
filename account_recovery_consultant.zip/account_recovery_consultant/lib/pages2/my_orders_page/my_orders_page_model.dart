import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_ad_banner.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:async';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/admob_util.dart' as admob;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'my_orders_page_widget.dart' show MyOrdersPageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class MyOrdersPageModel extends FlutterFlowModel<MyOrdersPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Firestore Query - Query a collection] action in my_orders_page widget.
  OrdersRecord? myOrderDoc;
  // Stores action output result for [Custom Action - runDailyLuck] action in my_orders_page widget.
  dynamic? luckResult;
  // Stores action output result for [Firestore Query - Query a collection] action in my_orders_page widget.
  AppConfigurationRecord? mmmm;
  // Stores action output result for [Custom Action - checkAdBlocker] action in Button widget.
  bool? isSafe;
  // Stores action output result for [Custom Action - showMyAd] action in Button widget.
  bool? masrawy;
  // Stores action output result for [Custom Action - loadRewardedInterstitialAd] action in Button widget.
  bool? isReady2;
  // Stores action output result for [Custom Action - showRewardedInterstitialAd] action in Button widget.
  bool? gotReward2;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  OrdersRecord? userOrderDoc2;
  // Stores action output result for [AdMob - Show Interstitial Ad] action in Button widget.
  bool? interstitialAdSuccess;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
