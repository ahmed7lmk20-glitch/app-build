import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_ad_banner.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:async';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/admob_util.dart' as admob;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'my_orders_page_model.dart';
export 'my_orders_page_model.dart';

class MyOrdersPageWidget extends StatefulWidget {
  const MyOrdersPageWidget({super.key});

  static String routeName = 'my_orders_page';
  static String routePath = '/myOrdersPage';

  @override
  State<MyOrdersPageWidget> createState() => _MyOrdersPageWidgetState();
}

class _MyOrdersPageWidgetState extends State<MyOrdersPageWidget> {
  late MyOrdersPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MyOrdersPageModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.myOrderDoc = await queryOrdersRecordOnce(
        queryBuilder: (ordersRecord) => ordersRecord.where(
          'user_id',
          isEqualTo: currentUserUid,
        ),
        singleRecord: true,
      ).then((s) => s.firstOrNull);
      _model.luckResult = await actions.runDailyLuck(
        valueOrDefault(currentUserDocument?.lastCheckDate, ''),
        _model.myOrderDoc?.queueNumber,
        _model.myOrderDoc?.streak,
      );
      if (getJsonField(
        _model.luckResult,
        r'''$.hasChanged''',
      )) {
        await currentUserReference!.update(createUsersRecordData(
          lastCheckDate: getJsonField(
            _model.luckResult,
            r'''$.todayStr''',
          ).toString(),
        ));

        await _model.myOrderDoc!.reference.update(createOrdersRecordData(
          queueNumber: getJsonField(
            _model.luckResult,
            r'''$.newOrder''',
          ),
          streak: getJsonField(
            _model.luckResult,
            r'''$.newStreak''',
          ),
        ));
        await showDialog(
          context: context,
          builder: (alertDialogContext) {
            return WebViewAware(
              child: AlertDialog(
                title: Text(FFLocalizations.of(context).getVariableText(
                  arText: 'حالة الترتيب',
                  enText: 'Queue Status',
                )),
                content: Text(FFLocalizations.of(context).languageCode == 'ar'
                    ? getJsonField(
                        _model.luckResult,
                        r'''$.messageAr''',
                      ).toString()
                    : getJsonField(
                        _model.luckResult,
                        r'''$.messageEn''',
                      ).toString()),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(alertDialogContext),
                    child: Text('Ok'),
                  ),
                ],
              ),
            );
          },
        );
      }
      if (FFAppState().pendingratingshow && (FFAppState().hasrated == false)) {
        await Future.delayed(
          Duration(
            milliseconds: 2000,
          ),
        );
        _model.mmmm = await queryAppConfigurationRecordOnce(
          singleRecord: true,
        ).then((s) => s.firstOrNull);
        await actions.showRatingBottomSheet(
          context,
          _model.mmmm!.ratingUrl,
        );
        FFAppState().pendingratingshow = false;
        FFAppState().hasrated = true;
        safeSetState(() {});
      }
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return StreamBuilder<List<OrdersRecord>>(
      stream: queryOrdersRecord(
        queryBuilder: (ordersRecord) => ordersRecord.where(
          'user_id',
          isEqualTo: currentUserUid != '' ? currentUserUid : null,
          isNull: (currentUserUid != '' ? currentUserUid : null) == null,
        ),
        limit: 1,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: Color(0xFFF1F4F8),
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        List<OrdersRecord> myOrdersPageOrdersRecordList = snapshot.data!;

        return GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: Color(0xFFF1F4F8),
            body: SafeArea(
              top: true,
              child: Container(
                width: MediaQuery.sizeOf(context).width * 1.0,
                height: MediaQuery.sizeOf(context).height * 1.0,
                child: Stack(
                  children: [
                    Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8.0),
                        child: Image.asset(
                          'assets/images/_2.jpg',
                          width: MediaQuery.sizeOf(context).width * 1.0,
                          height: MediaQuery.sizeOf(context).height * 1.0,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    Builder(
                      builder: (context) {
                        if (myOrdersPageOrdersRecordList.isNotEmpty) {
                          return Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Align(
                                alignment: AlignmentDirectional(0.0, 0.0),
                                child: FlutterFlowAdBanner(
                                  width: MediaQuery.sizeOf(context).width * 1.0,
                                  height: 50.0,
                                  showsTestAd: false,
                                  androidAdUnitID:
                                      'ca-app-pub-2079997928257932/1007847958',
                                ),
                              ),
                              Container(
                                width: MediaQuery.sizeOf(context).width * 1.0,
                                height: MediaQuery.sizeOf(context).height * 0.2,
                                decoration: BoxDecoration(),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    20.0, 0.0, 20.0, 0.0),
                                child: SingleChildScrollView(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            10.0, 0.0, 10.0, 0.0),
                                        child: Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.9,
                                          height: MediaQuery.sizeOf(context)
                                                  .height *
                                              0.31,
                                          decoration: BoxDecoration(
                                            color: Color(0xFFBBDDEE),
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(10.0),
                                              topRight: Radius.circular(10.0),
                                              bottomLeft: Radius.circular(10.0),
                                              bottomRight:
                                                  Radius.circular(10.0),
                                            ),
                                          ),
                                          alignment:
                                              AlignmentDirectional(0.0, 1.0),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.all(1.0),
                                                child: Text(
                                                  valueOrDefault<String>(
                                                    () {
                                                      if (myOrdersPageOrdersRecordList
                                                              .firstOrNull!
                                                              .queueNumber >
                                                          150) {
                                                        return FFLocalizations
                                                                .of(context)
                                                            .getVariableText(
                                                          arText:
                                                              'حالة الطلب: طلب جديد 🆕',
                                                          enText:
                                                              'Status: New Request 🆕',
                                                        );
                                                      } else if (myOrdersPageOrdersRecordList
                                                              .firstOrNull!
                                                              .queueNumber >
                                                          100) {
                                                        return FFLocalizations
                                                                .of(context)
                                                            .getVariableText(
                                                          arText:
                                                              'حالة الطلب: تابع تقدّمك 📊',
                                                          enText:
                                                              'Status: Track Your Progress 📊',
                                                        );
                                                      } else if (myOrdersPageOrdersRecordList
                                                              .firstOrNull!
                                                              .queueNumber >
                                                          50) {
                                                        return FFLocalizations
                                                                .of(context)
                                                            .getVariableText(
                                                          arText:
                                                              'حالة الطلب: استمر بالمهام للوصول أسرع 🚀',
                                                          enText:
                                                              'Status: Complete tasks to speed up 🚀',
                                                        );
                                                      } else if (myOrdersPageOrdersRecordList
                                                              .firstOrNull!
                                                              .queueNumber >
                                                          1) {
                                                        return FFLocalizations
                                                                .of(context)
                                                            .getVariableText(
                                                          arText:
                                                              'حالة الطلب: في اللمسات الأخيرة 🚀',
                                                          enText:
                                                              'Status: Final Touches 🚀',
                                                        );
                                                      } else {
                                                        return FFLocalizations
                                                                .of(context)
                                                            .getVariableText(
                                                          arText:
                                                              'حالة الطلب: جاري الاتصال بك في أقرب وقت 📞',
                                                          enText:
                                                              'Status: Contacting you shortly 📞',
                                                        );
                                                      }
                                                    }(),
                                                    'لا توجد طلبات قائمة حالياً 📋',
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontStyle:
                                                              FontStyle.italic,
                                                        ),
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .error,
                                                        fontSize: 15.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontStyle:
                                                            FontStyle.italic,
                                                      ),
                                                ),
                                              ),
                                              StreamBuilder<List<OrdersRecord>>(
                                                stream: queryOrdersRecord(
                                                  queryBuilder:
                                                      (ordersRecord) =>
                                                          ordersRecord.where(
                                                    'user_id',
                                                    isEqualTo: currentUserUid,
                                                  ),
                                                  limit: 1,
                                                ),
                                                builder: (context, snapshot) {
                                                  // Customize what your widget looks like when it's loading.
                                                  if (!snapshot.hasData) {
                                                    return Center(
                                                      child: SizedBox(
                                                        width: 50.0,
                                                        height: 50.0,
                                                        child:
                                                            CircularProgressIndicator(
                                                          valueColor:
                                                              AlwaysStoppedAnimation<
                                                                  Color>(
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primary,
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  }
                                                  List<OrdersRecord>
                                                      listViewOrdersRecordList =
                                                      snapshot.data!;
                                                  if (listViewOrdersRecordList
                                                      .isEmpty) {
                                                    return Image.asset(
                                                      'assets/images/__2026-06-19_235435.jpg',
                                                    );
                                                  }

                                                  return ListView.builder(
                                                    padding: EdgeInsets.zero,
                                                    primary: false,
                                                    shrinkWrap: true,
                                                    scrollDirection:
                                                        Axis.vertical,
                                                    itemCount:
                                                        listViewOrdersRecordList
                                                            .length,
                                                    itemBuilder: (context,
                                                        listViewIndex) {
                                                      final listViewOrdersRecord =
                                                          listViewOrdersRecordList[
                                                              listViewIndex];
                                                      return Row(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: [
                                                          Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceEvenly,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Padding(
                                                                padding:
                                                                    EdgeInsets
                                                                        .all(
                                                                            1.0),
                                                                child: Text(
                                                                  valueOrDefault<
                                                                      String>(
                                                                    '${FFLocalizations.of(context).getVariableText(
                                                                      arText:
                                                                          'اسم المنصة:  ',
                                                                      enText:
                                                                          'Platform:  ',
                                                                    )}${listViewOrdersRecord.platform}',
                                                                    'لا يوجد طلب',
                                                                  ),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        font: GoogleFonts
                                                                            .inter(
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                          fontStyle:
                                                                              FontStyle.italic,
                                                                        ),
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .primaryText,
                                                                        fontSize:
                                                                            14.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                        fontStyle:
                                                                            FontStyle.italic,
                                                                      ),
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    EdgeInsets
                                                                        .all(
                                                                            1.0),
                                                                child: Text(
                                                                  valueOrDefault<
                                                                      String>(
                                                                    '${FFLocalizations.of(context).getVariableText(
                                                                      arText:
                                                                          'رقم الدور:  ',
                                                                      enText:
                                                                          'Turn Number:  ',
                                                                    )}${listViewOrdersRecord.queueNumber.toString()}',
                                                                    'لا يوجد رقم',
                                                                  ),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        font: GoogleFonts
                                                                            .inter(
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                          fontStyle:
                                                                              FontStyle.italic,
                                                                        ),
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .primaryText,
                                                                        fontSize:
                                                                            14.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                        fontStyle:
                                                                            FontStyle.italic,
                                                                      ),
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    EdgeInsets
                                                                        .all(
                                                                            1.0),
                                                                child: Text(
                                                                  valueOrDefault<
                                                                      String>(
                                                                    '${FFLocalizations.of(context).getVariableText(
                                                                      arText:
                                                                          'تاريخ التقديم:  ',
                                                                      enText:
                                                                          'Submission Date:  ',
                                                                    )}${dateTimeFormat(
                                                                      "d/M/y",
                                                                      listViewOrdersRecord
                                                                          .createdAt,
                                                                      locale: FFLocalizations.of(
                                                                              context)
                                                                          .languageCode,
                                                                    )}',
                                                                    'لا يوجد تاريخ',
                                                                  ),
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        font: GoogleFonts
                                                                            .inter(
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                          fontStyle:
                                                                              FontStyle.italic,
                                                                        ),
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .primaryText,
                                                                        fontSize:
                                                                            14.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                        fontStyle:
                                                                            FontStyle.italic,
                                                                      ),
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            3.0,
                                                                            0.0,
                                                                            6.0),
                                                                child:
                                                                    FFButtonWidget(
                                                                  onPressed:
                                                                      () async {
                                                                    var confirmDialogResponse =
                                                                        await showDialog<bool>(
                                                                              context: context,
                                                                              builder: (alertDialogContext) {
                                                                                return WebViewAware(
                                                                                  child: AlertDialog(
                                                                                    title: Text(FFLocalizations.of(context).getVariableText(
                                                                                      arText: 'تأكيد حذف الطلب',
                                                                                      enText: 'Confirm Order Deletion',
                                                                                    )),
                                                                                    content: Text(FFLocalizations.of(context).getVariableText(
                                                                                      arText: 'هل أنت متأكد من رغبتك في حذف الطلب؟ سيتم إعادة ضبط الترتيب',
                                                                                      enText: 'Are you sure you want to delete the order? The queue will be reset.',
                                                                                    )),
                                                                                    actions: [
                                                                                      TextButton(
                                                                                        onPressed: () => Navigator.pop(alertDialogContext, false),
                                                                                        child: Text(FFLocalizations.of(context).getVariableText(
                                                                                          arText: 'إلغاء',
                                                                                          enText: 'Cancel',
                                                                                        )),
                                                                                      ),
                                                                                      TextButton(
                                                                                        onPressed: () => Navigator.pop(alertDialogContext, true),
                                                                                        child: Text(FFLocalizations.of(context).getVariableText(
                                                                                          arText: 'موافق',
                                                                                          enText: 'OK',
                                                                                        )),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                );
                                                                              },
                                                                            ) ??
                                                                            false;
                                                                    if (confirmDialogResponse) {
                                                                      if (Navigator.of(
                                                                              context)
                                                                          .canPop()) {
                                                                        context
                                                                            .pop();
                                                                      }
                                                                      context.pushNamed(
                                                                          CreateOrderPageWidget
                                                                              .routeName);

                                                                      unawaited(
                                                                        () async {
                                                                          await myOrdersPageOrdersRecordList
                                                                              .firstOrNull!
                                                                              .reference
                                                                              .delete();
                                                                        }(),
                                                                      );
                                                                      unawaited(
                                                                        () async {
                                                                          await currentUserReference!
                                                                              .update(createUsersRecordData(
                                                                            isTaskCompleted:
                                                                                false,
                                                                            isBonusClaimed:
                                                                                false,
                                                                          ));
                                                                        }(),
                                                                      );
                                                                    } else {
                                                                      await showDialog(
                                                                        context:
                                                                            context,
                                                                        builder:
                                                                            (alertDialogContext) {
                                                                          return WebViewAware(
                                                                            child:
                                                                                AlertDialog(
                                                                              content: Text(FFLocalizations.of(context).getVariableText(
                                                                                arText: 'تم إلغاء عملية الحذف.',
                                                                                enText: 'Deletion canceled.',
                                                                              )),
                                                                              actions: [
                                                                                TextButton(
                                                                                  onPressed: () => Navigator.pop(alertDialogContext),
                                                                                  child: Text('Ok'),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          );
                                                                        },
                                                                      );
                                                                    }
                                                                  },
                                                                  text: FFLocalizations.of(
                                                                          context)
                                                                      .getText(
                                                                    '0izk80qn' /* حذف الطلب */,
                                                                  ),
                                                                  options:
                                                                      FFButtonOptions(
                                                                    height:
                                                                        25.0,
                                                                    padding: EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            16.0,
                                                                            0.0,
                                                                            16.0,
                                                                            0.0),
                                                                    iconPadding:
                                                                        EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                    color: Color(
                                                                        0xFFF40408),
                                                                    textStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .override(
                                                                          font:
                                                                              GoogleFonts.interTight(
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            fontStyle:
                                                                                FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                          ),
                                                                          color:
                                                                              Colors.white,
                                                                          fontSize:
                                                                              14.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                          fontStyle: FlutterFlowTheme.of(context)
                                                                              .titleSmall
                                                                              .fontStyle,
                                                                        ),
                                                                    elevation:
                                                                        0.0,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            8.0),
                                                                  ),
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    EdgeInsets
                                                                        .all(
                                                                            3.0),
                                                                child:
                                                                    Container(
                                                                  width: MediaQuery.sizeOf(
                                                                              context)
                                                                          .width *
                                                                      0.75,
                                                                  height: MediaQuery.sizeOf(
                                                                              context)
                                                                          .height *
                                                                      0.08,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: Color(
                                                                        0xFFFEF9C3),
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .only(
                                                                      topLeft: Radius
                                                                          .circular(
                                                                              15.0),
                                                                      topRight:
                                                                          Radius.circular(
                                                                              15.0),
                                                                      bottomLeft:
                                                                          Radius.circular(
                                                                              15.0),
                                                                      bottomRight:
                                                                          Radius.circular(
                                                                              15.0),
                                                                    ),
                                                                  ),
                                                                  child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .max,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    children: [
                                                                      Text(
                                                                        FFLocalizations.of(context)
                                                                            .getText(
                                                                          '8pqh0106' /* سنتصل بك عندما يصبح دورك ( 1 )... */,
                                                                        ),
                                                                        textAlign:
                                                                            TextAlign.center,
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              font: GoogleFonts.inter(
                                                                                fontWeight: FontWeight.bold,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                              ),
                                                                              color: Color(0xFF78350F),
                                                                              fontSize: 15.0,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FontWeight.bold,
                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                            ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      );
                                                    },
                                                  );
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 5.0, 0.0, 5.0),
                                child: Container(
                                  width:
                                      MediaQuery.sizeOf(context).width * 0.85,
                                  height:
                                      MediaQuery.sizeOf(context).height * 0.05,
                                  decoration: BoxDecoration(
                                    color: Color(0xFF1E293B),
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(10.0),
                                      topRight: Radius.circular(10.0),
                                      bottomLeft: Radius.circular(10.0),
                                      bottomRight: Radius.circular(10.0),
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        FFLocalizations.of(context).getText(
                                          'oizbedf1' /* 🎯 نفّذ المهمات عشان طلبك يخلص... */,
                                        ),
                                        textAlign: TextAlign.center,
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              font: GoogleFonts.inter(
                                                fontWeight: FontWeight.w600,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .fontStyle,
                                              ),
                                              color: Color(0xFFFACC15),
                                              fontSize: 15.0,
                                              letterSpacing: 0.0,
                                              fontWeight: FontWeight.w600,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .fontStyle,
                                            ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              if (myOrdersPageOrdersRecordList.isNotEmpty)
                                Column(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 10.0, 0.0, 10.0),
                                      child: StreamBuilder<
                                          List<AppConfigurationRecord>>(
                                        stream: queryAppConfigurationRecord(
                                          singleRecord: true,
                                        ),
                                        builder: (context, snapshot) {
                                          // Customize what your widget looks like when it's loading.
                                          if (!snapshot.hasData) {
                                            return Center(
                                              child: SizedBox(
                                                width: 50.0,
                                                height: 50.0,
                                                child:
                                                    CircularProgressIndicator(
                                                  valueColor:
                                                      AlwaysStoppedAnimation<
                                                          Color>(
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                  ),
                                                ),
                                              ),
                                            );
                                          }
                                          List<AppConfigurationRecord>
                                              buttonAppConfigurationRecordList =
                                              snapshot.data!;
                                          // Return an empty Container when the item does not exist.
                                          if (snapshot.data!.isEmpty) {
                                            return Container();
                                          }
                                          final buttonAppConfigurationRecord =
                                              buttonAppConfigurationRecordList
                                                      .isNotEmpty
                                                  ? buttonAppConfigurationRecordList
                                                      .first
                                                  : null;

                                          return FFButtonWidget(
                                            onPressed: () async {
                                              if (functions.checkResetTime(
                                                  FFAppState().adResetTime!,
                                                  getCurrentTimestamp)) {
                                                FFAppState().adCount = 0;
                                                FFAppState().adResetTime =
                                                    getCurrentTimestamp;
                                                safeSetState(() {});
                                              }
                                              _model.isSafe =
                                                  await actions.checkAdBlocker(
                                                context,
                                              );
                                              if (_model.isSafe!) {
                                                if (FFAppState().adCount <
                                                    buttonAppConfigurationRecord!
                                                        .maxAttempts) {
                                                  _model.masrawy =
                                                      await actions.showMyAd(
                                                    context,
                                                  );
                                                  if (_model.masrawy!) {
                                                    FFAppState().adCount =
                                                        FFAppState().adCount +
                                                            1;
                                                    FFAppState().adResetTime =
                                                        FFAppState().adCount ==
                                                                1
                                                            ? getCurrentTimestamp
                                                            : FFAppState()
                                                                .adResetTime;
                                                    await Future.delayed(
                                                      Duration(
                                                        milliseconds: 600,
                                                      ),
                                                    );

                                                    await myOrdersPageOrdersRecordList
                                                        .firstOrNull!.reference
                                                        .update({
                                                      ...mapToFirestore(
                                                        {
                                                          'queue_number': FieldValue
                                                              .increment(-((int
                                                                  currentqueue) {
                                                            return currentqueue >
                                                                    40
                                                                ? 2
                                                                : 1;
                                                          }(myOrdersPageOrdersRecordList
                                                                  .firstOrNull!
                                                                  .queueNumber))),
                                                        },
                                                      ),
                                                    });
                                                    ScaffoldMessenger.of(
                                                            context)
                                                        .showSnackBar(
                                                      SnackBar(
                                                        content: Text(
                                                          FFLocalizations.of(
                                                                  context)
                                                              .getVariableText(
                                                            arText:
                                                                '\"تمت العملية بنجاح! يمكنك طلب مكافأة أخرى الآن.\"',
                                                            enText:
                                                                '\"Success! You can claim another reward now.\"',
                                                          ),
                                                          style: TextStyle(
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .primaryText,
                                                          ),
                                                          textAlign:
                                                              TextAlign.center,
                                                        ),
                                                        duration: Duration(
                                                            milliseconds: 4000),
                                                        backgroundColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .secondary,
                                                      ),
                                                    );
                                                  } else {
                                                    await showDialog(
                                                      context: context,
                                                      builder:
                                                          (alertDialogContext) {
                                                        return WebViewAware(
                                                          child: AlertDialog(
                                                            title: Text(
                                                                FFLocalizations.of(
                                                                        context)
                                                                    .getVariableText(
                                                              arText:
                                                                  'تنبيه 🛑',
                                                              enText:
                                                                  '🛑 Action Required',
                                                            )),
                                                            content: Text(
                                                                FFLocalizations.of(
                                                                        context)
                                                                    .getVariableText(
                                                              arText:
                                                                  'لقد قمت بإغلاق الإعلان مبكراً، ولن تتمكن من الاستفادة من الخدمة.  يرجى مشاهدة الإعلان كاملاً حتى النهاية لكي يتم تفعيل الخدمة لك بنجاح.',
                                                              enText:
                                                                  'You closed the ad early, so the service could not be activated.  Please watch the ad until the very end to enjoy the service successfully.',
                                                            )),
                                                            actions: [
                                                              TextButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                        alertDialogContext),
                                                                child:
                                                                    Text('Ok'),
                                                              ),
                                                            ],
                                                          ),
                                                        );
                                                      },
                                                    );
                                                  }
                                                } else {
                                                  await showDialog(
                                                    context: context,
                                                    builder:
                                                        (alertDialogContext) {
                                                      return WebViewAware(
                                                        child: AlertDialog(
                                                          title: Text(
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .getVariableText(
                                                            arText:
                                                                'انتهت محاولات اليوم 🕒',
                                                            enText:
                                                                '🕒 Limit Reached',
                                                          )),
                                                          content: Text(
                                                              FFLocalizations.of(
                                                                      context)
                                                                  .getVariableText(
                                                            arText:
                                                                '🎉 انتهت محاولاتك اليوم بنجاح! ننتظرك غداً للحصول على محاولات جديدة واستخدام الخدمة.',
                                                            enText:
                                                                '🎉 You\'ve used all attempts for today! See you tomorrow for new ones.',
                                                          )),
                                                          actions: [
                                                            TextButton(
                                                              onPressed: () =>
                                                                  Navigator.pop(
                                                                      alertDialogContext),
                                                              child: Text('Ok'),
                                                            ),
                                                          ],
                                                        ),
                                                      );
                                                    },
                                                  );
                                                }
                                              } else {
                                                await showDialog(
                                                  context: context,
                                                  builder:
                                                      (alertDialogContext) {
                                                    return WebViewAware(
                                                      child: AlertDialog(
                                                        title: Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getVariableText(
                                                          arText: 'تنبيه ⚠️',
                                                          enText:
                                                              '⚠️ Connection Notice',
                                                        )),
                                                        content: Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getVariableText(
                                                          arText:
                                                              '❌ فشل تحميل الإعلان. يرجى التحقق من الإنترنت أو إيقاف مانع الإعلانات (AdBlocker) والمحاولة مجدداً.',
                                                          enText:
                                                              '❌ Failed to load ad. Please check your internet or disable AdBlocker and try again.',
                                                        )),
                                                        actions: [
                                                          TextButton(
                                                            onPressed: () =>
                                                                Navigator.pop(
                                                                    alertDialogContext),
                                                            child: Text('Ok'),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  },
                                                );
                                              }

                                              safeSetState(() {});
                                            },
                                            text: myOrdersPageOrdersRecordList
                                                        .firstOrNull!
                                                        .queueNumber >
                                                    40
                                                ? FFLocalizations.of(context)
                                                    .getVariableText(
                                                    arText:
                                                        'شاهد إعلان لخصم ( 2 ) أدوار فوري 🚀',
                                                    enText:
                                                        'Watch ad to skip ( 2 ) spots! 🚀',
                                                  )
                                                : FFLocalizations.of(context)
                                                    .getVariableText(
                                                    arText:
                                                        'شاهد إعلان لتحسين ترتيبك 🏁',
                                                    enText:
                                                        'Watch ad to boost your rank! 🏁',
                                                  ),
                                            options: FFButtonOptions(
                                              width: MediaQuery.sizeOf(context)
                                                      .width *
                                                  0.85,
                                              height: 40.0,
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(0.0, 0.0, 0.0, 0.0),
                                              iconPadding: EdgeInsetsDirectional
                                                  .fromSTEB(0.0, 0.0, 0.0, 0.0),
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondary,
                                              textStyle: FlutterFlowTheme.of(
                                                      context)
                                                  .titleSmall
                                                  .override(
                                                    font:
                                                        GoogleFonts.interTight(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .titleSmall
                                                              .fontStyle,
                                                    ),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primaryText,
                                                    fontSize: 15.0,
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.bold,
                                                    fontStyle:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .titleSmall
                                                            .fontStyle,
                                                  ),
                                              elevation: 0.0,
                                              borderRadius: BorderRadius.only(
                                                topLeft: Radius.circular(10.0),
                                                topRight: Radius.circular(10.0),
                                                bottomLeft:
                                                    Radius.circular(10.0),
                                                bottomRight:
                                                    Radius.circular(10.0),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 0.0, 10.0),
                                      child: StreamBuilder<
                                          List<AppConfigurationRecord>>(
                                        stream: queryAppConfigurationRecord(
                                          singleRecord: true,
                                        ),
                                        builder: (context, snapshot) {
                                          // Customize what your widget looks like when it's loading.
                                          if (!snapshot.hasData) {
                                            return Center(
                                              child: SizedBox(
                                                width: 50.0,
                                                height: 50.0,
                                                child:
                                                    CircularProgressIndicator(
                                                  valueColor:
                                                      AlwaysStoppedAnimation<
                                                          Color>(
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                  ),
                                                ),
                                              ),
                                            );
                                          }
                                          List<AppConfigurationRecord>
                                              buttonAppConfigurationRecordList =
                                              snapshot.data!;
                                          // Return an empty Container when the item does not exist.
                                          if (snapshot.data!.isEmpty) {
                                            return Container();
                                          }
                                          final buttonAppConfigurationRecord =
                                              buttonAppConfigurationRecordList
                                                      .isNotEmpty
                                                  ? buttonAppConfigurationRecordList
                                                      .first
                                                  : null;

                                          return FFButtonWidget(
                                            onPressed: () async {
                                              _model.isReady2 = await actions
                                                  .loadRewardedInterstitialAd(
                                                context,
                                              );
                                              if (_model.isReady2 == true) {
                                                _model.gotReward2 = await actions
                                                    .showRewardedInterstitialAd(
                                                  context,
                                                );
                                                if (_model.gotReward2!) {
                                                  _model.userOrderDoc2 =
                                                      await queryOrdersRecordOnce(
                                                    queryBuilder:
                                                        (ordersRecord) =>
                                                            ordersRecord.where(
                                                      'user_id',
                                                      isEqualTo: currentUserUid,
                                                    ),
                                                    singleRecord: true,
                                                  ).then((s) => s.firstOrNull);
                                                  if (_model.userOrderDoc2 !=
                                                      null) {
                                                    await _model.userOrderDoc2!
                                                        .reference
                                                        .update({
                                                      ...mapToFirestore(
                                                        {
                                                          'queue_number':
                                                              FieldValue
                                                                  .increment(
                                                                      -(1)),
                                                        },
                                                      ),
                                                    });
                                                    ScaffoldMessenger.of(
                                                            context)
                                                        .showSnackBar(
                                                      SnackBar(
                                                        content: Text(
                                                          FFLocalizations.of(
                                                                  context)
                                                              .getVariableText(
                                                            arText:
                                                                'تم خصم 1 دور من ترتيبك بنجاح 🎁',
                                                            enText:
                                                                '1 turn successfully deducted from your queue! 🎁',
                                                          ),
                                                          style: TextStyle(
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .primaryText,
                                                          ),
                                                          textAlign:
                                                              TextAlign.center,
                                                        ),
                                                        duration: Duration(
                                                            milliseconds: 3000),
                                                        backgroundColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .secondary,
                                                      ),
                                                    );

                                                    context.pushNamed(
                                                        PublishGuidePageWidget
                                                            .routeName);
                                                  } else {
                                                    context.pushNamed(
                                                        PublishGuidePageWidget
                                                            .routeName);
                                                  }
                                                } else {
                                                  context.pushNamed(
                                                      PublishGuidePageWidget
                                                          .routeName);
                                                }
                                              } else {
                                                context.pushNamed(
                                                    PublishGuidePageWidget
                                                        .routeName);
                                              }

                                              safeSetState(() {});
                                            },
                                            text: FFLocalizations.of(context)
                                                .getText(
                                              '6qintmku' /*  أكمل المهمة الكبرى واخصم (100... */,
                                            ),
                                            options: FFButtonOptions(
                                              width: MediaQuery.sizeOf(context)
                                                      .width *
                                                  0.85,
                                              height: 40.0,
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      16.0, 0.0, 16.0, 0.0),
                                              iconPadding: EdgeInsetsDirectional
                                                  .fromSTEB(0.0, 0.0, 0.0, 0.0),
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondary,
                                              textStyle: FlutterFlowTheme.of(
                                                      context)
                                                  .titleSmall
                                                  .override(
                                                    font:
                                                        GoogleFonts.interTight(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .titleSmall
                                                              .fontStyle,
                                                    ),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primaryText,
                                                    fontSize: 15.0,
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.bold,
                                                    fontStyle:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .titleSmall
                                                            .fontStyle,
                                                  ),
                                              elevation: 0.0,
                                              borderRadius: BorderRadius.only(
                                                topLeft: Radius.circular(10.0),
                                                topRight: Radius.circular(10.0),
                                                bottomLeft:
                                                    Radius.circular(10.0),
                                                bottomRight:
                                                    Radius.circular(10.0),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 0.0, 10.0),
                                      child: StreamBuilder<
                                          List<AppConfigurationRecord>>(
                                        stream: queryAppConfigurationRecord(
                                          singleRecord: true,
                                        ),
                                        builder: (context, snapshot) {
                                          // Customize what your widget looks like when it's loading.
                                          if (!snapshot.hasData) {
                                            return Center(
                                              child: SizedBox(
                                                width: 50.0,
                                                height: 50.0,
                                                child:
                                                    CircularProgressIndicator(
                                                  valueColor:
                                                      AlwaysStoppedAnimation<
                                                          Color>(
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                  ),
                                                ),
                                              ),
                                            );
                                          }
                                          List<AppConfigurationRecord>
                                              buttonAppConfigurationRecordList =
                                              snapshot.data!;
                                          // Return an empty Container when the item does not exist.
                                          if (snapshot.data!.isEmpty) {
                                            return Container();
                                          }
                                          final buttonAppConfigurationRecord =
                                              buttonAppConfigurationRecordList
                                                      .isNotEmpty
                                                  ? buttonAppConfigurationRecordList
                                                      .first
                                                  : null;

                                          return FFButtonWidget(
                                            onPressed: () async {
                                              await launchURL(
                                                  buttonAppConfigurationRecord!
                                                      .ratingUrl);
                                              ScaffoldMessenger.of(context)
                                                  .showSnackBar(
                                                SnackBar(
                                                  content: Text(
                                                    FFLocalizations.of(context)
                                                        .getVariableText(
                                                      arText:
                                                          'جاري فتح تطبيق المحادثة...',
                                                      enText:
                                                          'Opening the chat app...',
                                                    ),
                                                    style: TextStyle(
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .primaryText,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                  duration: Duration(
                                                      milliseconds: 10000),
                                                  backgroundColor:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .secondary,
                                                ),
                                              );
                                              await Future.delayed(
                                                Duration(
                                                  milliseconds: 13000,
                                                ),
                                              );
                                            },
                                            text: FFLocalizations.of(context)
                                                .getText(
                                              'kdgf2jre' /* الشكاوى والدعم الفني */,
                                            ),
                                            options: FFButtonOptions(
                                              width: MediaQuery.sizeOf(context)
                                                      .width *
                                                  0.85,
                                              height: 40.0,
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      16.0, 0.0, 16.0, 0.0),
                                              iconPadding: EdgeInsetsDirectional
                                                  .fromSTEB(0.0, 0.0, 0.0, 0.0),
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondary,
                                              textStyle: FlutterFlowTheme.of(
                                                      context)
                                                  .titleSmall
                                                  .override(
                                                    font:
                                                        GoogleFonts.interTight(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .titleSmall
                                                              .fontStyle,
                                                    ),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primaryText,
                                                    fontSize: 15.0,
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.bold,
                                                    fontStyle:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .titleSmall
                                                            .fontStyle,
                                                  ),
                                              elevation: 0.0,
                                              borderRadius: BorderRadius.only(
                                                topLeft: Radius.circular(10.0),
                                                topRight: Radius.circular(10.0),
                                                bottomLeft:
                                                    Radius.circular(10.0),
                                                bottomRight:
                                                    Radius.circular(10.0),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              Spacer(),
                            ],
                          );
                        } else {
                          return Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Align(
                                alignment: AlignmentDirectional(0.0, 0.0),
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 10.0),
                                  child: FlutterFlowAdBanner(
                                    width:
                                        MediaQuery.sizeOf(context).width * 1.0,
                                    height: 50.0,
                                    showsTestAd: false,
                                    androidAdUnitID:
                                        'ca-app-pub-2079997928257932/1007847958',
                                  ),
                                ),
                              ),
                              Container(
                                width: 100.0,
                                height:
                                    MediaQuery.sizeOf(context).height * 0.25,
                                decoration: BoxDecoration(),
                              ),
                              Padding(
                                padding: EdgeInsets.all(30.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'i6u5ydak' /* لا توجد طلبات قائمة حالياً 📋 */,
                                  ),
                                  textAlign: TextAlign.center,
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        font: GoogleFonts.inter(
                                          fontWeight: FontWeight.bold,
                                          fontStyle: FontStyle.italic,
                                        ),
                                        color: FlutterFlowTheme.of(context)
                                            .alternate,
                                        fontSize: 17.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.bold,
                                        fontStyle: FontStyle.italic,
                                      ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.all(10.0),
                                child: FFButtonWidget(
                                  onPressed: () async {
                                    admob.loadInterstitialAd(
                                      "",
                                      "ca-app-pub-2079997928257932/8221426909",
                                      false,
                                    );

                                    await Future.delayed(
                                      Duration(
                                        milliseconds: 4000,
                                      ),
                                    );

                                    _model.interstitialAdSuccess =
                                        await admob.showInterstitialAd();

                                    context.pushNamed(
                                        CreateOrderPageWidget.routeName);

                                    safeSetState(() {});
                                  },
                                  text: FFLocalizations.of(context).getText(
                                    'y63h2xrw' /* تقديم طلب جديد ➕ */,
                                  ),
                                  options: FFButtonOptions(
                                    width:
                                        MediaQuery.sizeOf(context).width * 0.8,
                                    height: MediaQuery.sizeOf(context).height *
                                        0.05,
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        16.0, 0.0, 16.0, 0.0),
                                    iconPadding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 0.0, 0.0),
                                    color:
                                        FlutterFlowTheme.of(context).secondary,
                                    textStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          font: GoogleFonts.interTight(
                                            fontWeight: FontWeight.bold,
                                            fontStyle: FontStyle.italic,
                                          ),
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                          fontStyle: FontStyle.italic,
                                        ),
                                    elevation: 0.0,
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                ),
                              ),
                            ],
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
