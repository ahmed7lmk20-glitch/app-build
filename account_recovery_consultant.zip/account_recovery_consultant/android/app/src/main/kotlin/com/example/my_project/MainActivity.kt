package com.mycompany.masrawy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
